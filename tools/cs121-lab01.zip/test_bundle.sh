#!/bin/bash
# Author: Luke Hindman
# Date: Tue 31 Aug 2021 03:24:14 PM MDT
# Description:  Test bundle for CS121-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (EmergencyTest)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-EmergencyTest"
	local testprogram="EmergencyTest.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (EmergencyTest.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-EmergencyTest"
	local mainsrc="EmergencyTest.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (EmergencyTest)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A1-EmergencyTest"
	local testprogram="EmergencyTest.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (EmergencyTest)"
	local testoutput="quality-test-activity1.out"
	local testinput=""
	local testdirectory="A1-EmergencyTest"
	local testprogram="java EmergencyTest"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (An Emergency Broadcast)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="An Emergency Broadcast"
	local testdirectory="A1-EmergencyTest"
	local testprogram="java EmergencyTest"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################
function acceptance-test-activity3-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 3 (PersonalBio)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="A3-PersonalBio"
	local testprogram="PersonalBio.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (PersonalBio.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-PersonalBio"
	local mainsrc="PersonalBio.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (PersonalBio)"
	local testoutput="quality-test-activity3.out"
	local testdirectory="A3-PersonalBio"
	local testprogram="PersonalBio.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (PersonalBio)"
	local testoutput="quality-test-activity3.out"
	local testinput=""
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (Name Label)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput="[N|n]ame"
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (Birthday Label)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput="[B|b]irthday"
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (Hobby Label)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput="[H|h]obb"
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (Book Label)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput="[B|b]ook"
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (Movie Label)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput="[M|m]ovie"
	local testdirectory="A3-PersonalBio"
	local testprogram="java PersonalBio"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	echo "Lab Activity Acceptance Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "21" ];
then
	# LabActivity Code Quality Tests
	echo "Lab Activity Quality Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "22" ];
then
	# LabActivity Unit Tests
	echo "Lab Activity Integration Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity3-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "32" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	integration-test-activity3-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=5
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


