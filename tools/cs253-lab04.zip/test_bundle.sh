#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 08 Feb 2021 10:59:58 AM MST
# Description:  Test bundle for CS253-Lab04


###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Build Check"
	testoutput="quality-test-labwarmup.out"
	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? != 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Oil change"


	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Oil change"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? != 127 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-check-oil() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Oil change"
	testoutput="unit-test-labwarmup.out"
	testinput="Oil change"
	expectedoutput="35"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-check-tire() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Tire rotation"
	testoutput="unit-test-labwarmup.out"
	testinput="Tire rotation"
	expectedoutput='19'

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}
function unit-test-labwarmup-check-car() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Car wash"
	testoutput="unit-test-labwarmup.out"
	testinput="Car wash"
	expectedoutput="7"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"

	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-build-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Build Check"
	testoutput="quality-test-labactivity.out"
	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? != 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labactivity-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="Oil change\nTire rotation"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="Oil change\nTire rotation"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? != 127 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-services1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Oil change & Car wax"
	testoutput="unit-test-labactivity.out"
	testinput="Oil change\nCar wax"
	expectedoutput="47"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}
function unit-test-labactivity-check-services2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Oil change & Car wash"
	testoutput="unit-test-labactivity.out"
	testinput="Oil change\nCar wash"
	expectedoutput="42"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-services3() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Oil change & Tire rotation"
	testoutput="unit-test-labactivity.out"
	testinput="Oil change\nTire rotation"
	expectedoutput="54"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-services4() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Car wash & Car wax"
	testoutput="unit-test-labactivity.out"
	testinput="Car wash\nCar wax"
	expectedoutput="19"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-no-service1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Tire rotation & No service"
	testoutput="unit-test-labactivity.out"
	testinput="Tire rotation\n-"
	expectedoutput="No service"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-no-service2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - No service & Oil change"
	testoutput="unit-test-labactivity.out"
	testinput="-\nOil change"
	expectedoutput="[N|n]o [S|s]ervice"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
    duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi
	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	unit-test-labwarmup-check-oil $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-check-tire $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-check-car $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Completeness Tests
	unit-test-labactivity-check-services1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-services2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi
	
	unit-test-labactivity-check-services3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-services4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-no-service1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-no-service2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ];
then
	# Coding Journal Content Review
	unit-test-labactivity-check-gallons $verbose
	error_count=$(($error_count + $?))
else
	echo "unknown test $testnum"
fi

exit ${error_count}


