#!/bin/bash
# Author: Luke Hindman
# Date:  Sun 24 Jan 2021 05:25:22 PM MST
# Description:  Test bundle for CS253-Lab01

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################
function acceptance-test-labwarmup-build-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Build (myprog)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (Hello world!)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="[H|h]ello [W|w]orld!"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (How are you?)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="How are you?"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (I'm fine)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="I'm fine"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup-build-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	integration-test-labwarmup-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	echo "Lab Activity Acceptance Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "21" ];
then
	# LabActivity Code Quality Tests
	echo "Lab Activity Quality Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "22" ];
then
	# LabActivity Unit Tests
	echo "Lab Activity Integration Tests: Not Implemented"
	exit 1
elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


