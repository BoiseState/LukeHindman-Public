#!/bin/bash
# Author: Luke Hindman
# Date:  Tue 20 Apr 2021 11:50:57 AM MDT
# Description:  Test bundle for CS253-Lab13

source test_functions.sh

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity-build-mycat() {
	local verbose=$1
	local testname="Acceptance Test - Build (mycat)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="mycat"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-mycat() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (mycat.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="mycat.c"
	local minlines=25
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-build-mygrep() {
	local verbose=$1
	local testname="Acceptance Test - Build (mygrep)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="mygrep"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-mygrep() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (mygrep.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="mygrep.c"
	local minlines=25
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-build-mywc() {
	local verbose=$1
	local testname="Acceptance Test - Build (mywc)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="mywc"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-mywc() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (mywc.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="mywc.c"
	local minlines=25
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-build-mysort() {
	local verbose=$1
	local testname="Acceptance Test - Build (mysort)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="mysort"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-mysort() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (mysort.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="mysort.c"
	local minlines=25
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="none"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check-mycat() {
	local verbose=$1
	local testname="Quality Test - Run Check (mycat)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mycat -f ../sample_data/american-english"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check-mycat() {
	local verbose=$1
	local testname="Quality Test - Memory Check (mycat)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mycat -f ../sample_data/american-english"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check-mygrep() {
	local verbose=$1
	local testname="Quality Test - Run Check (mygrep)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mygrep -f ../sample_data/american-english -s tree"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check-mygrep() {
	local verbose=$1
	local testname="Quality Test - Memory Check (mygrep)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mygrep -f ../sample_data/american-english -s tree"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check-mywc() {
	local verbose=$1
	local testname="Quality Test - Run Check (mywc)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mywc -f ../sample_data/american-english"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check-mywc() {
	local verbose=$1
	local testname="Quality Test - Memory Check (mywc)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mywc -f ../sample_data/american-english"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check-mysort() {
	local verbose=$1
	local testname="Quality Test - Run Check (mysort)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mysort -f ../sample_data/american-english -r"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check-mysort() {
	local verbose=$1
	local testname="Quality Test - Memory Check (mysort)"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mysort -f ../sample_data/american-english -r"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mycat-from-file() {
	local verbose=$1
	local testname="Integration Test - MyCat from File"
	local testoutput="integration-test-labactivity.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/american-english"
	local testdirectory="LabActivity"
	local testprogram="mycat -f ../sample_data/american-english"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mycat-from-stdin() {
	local verbose=$1
	local testname="Integration Test - MyCat from STDIN"
	local testoutput="integration-test-labactivity.out"
	local testinputfile="../sample_data/american-english"
	local expectedoutputfile="../sample_data/american-english"
	local testdirectory="LabActivity"
	local testprogram="mycat"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-mygrep-from-file() {
	local verbose=$1
	local testname="Integration Test - MyGrep from File"
	local testoutput="integration-test-labactivity.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/grep.results.out"
	local testdirectory="LabActivity"
	local testprogram="mygrep -s war -f ../sample_data/War-and-Peace.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mygrep-from-stdin() {
	local verbose=$1
	local testname="Integration Test - MyGrep from STDIN"
	local testoutput="integration-test-labactivity.out"
	local testinputfile="../sample_data/War-and-Peace.txt"
	local expectedoutputfile="../sample_data/grep.results.out"
	local testdirectory="LabActivity"
	local testprogram="mygrep -s war"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mywc-count-chars() {
	local verbose=$1
	local testname="Integration Test - MyWc count Characters"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="3359550"
	local testdirectory="LabActivity"
	local testprogram="mywc -c -f ../sample_data/War-and-Peace.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mywc-count-lines() {
	local verbose=$1
	local testname="Integration Test - MyWc count Lines"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="66055"
	local testdirectory="LabActivity"
	local testprogram="mywc -l -f ../sample_data/War-and-Peace.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mywc-count-words() {
	local verbose=$1
	local testname="Integration Test - MyWc count Words"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="(580201|566309)"
	local testdirectory="LabActivity"
	local testprogram="mywc -w -f ../sample_data/War-and-Peace.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mysort-ascending() {
	local verbose=$1
	local testname="Integration Test - MySort RandomWords Ascending"
	local testoutput="integration-test-labactivity.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/mysort.results.ascending.out"
	local testdirectory="LabActivity"
	local testprogram="mysort -f ../sample_data/random_words.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-mysort-descending() {
	local verbose=$1
	local testname="Integration Test - MySort RandomWords Descending"
	local testoutput="integration-test-labactivity.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/mysort.results.descending.out"
	local testdirectory="LabActivity"
	local testprogram="mysort -r -f ../sample_data/random_words.txt"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build-mycat $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-mycat $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-build-mygrep $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-mygrep $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-build-mywc $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# acceptance-test-labactivity-min-implementation-mywc $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-build-mysort $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# acceptance-test-labactivity-min-implementation-mysort $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=6
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check-mycat $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check-mycat $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check-mygrep $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check-mygrep $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check-mywc $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check-mywc $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check-mysort $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check-mysort $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=9
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	integration-test-labactivity-mycat-from-file $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mycat-from-stdin $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mygrep-from-file $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mygrep-from-stdin $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mywc-count-chars $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mywc-count-lines $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mywc-count-words $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mysort-ascending $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-mysort-descending $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=9

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ]; then
	num_passed=0

	# One-off testing
	num_tests=1

	integration-test-labactivity-sorted-students-gradebook $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

else
	echo "unknown test $testnum"
fi

exit ${error_count}
