#!/bin/bash
# Author: Luke Hindman
# Date: Wed 27 Oct 2021 11:09:12 AM MDT
# Description:  Test bundle for CS121-Lab05

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (CountFlips)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-CountFlips"
	local testprogram="CountFlips.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (CountFlips.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-CountFlips"
	local mainsrc="CountFlips.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Coin.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-CountFlips"
	local mainsrc="Coin.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (CountFlips)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A1-CountFlips"
	local testprogram="CountFlips.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (CountFlips)"
	local testoutput="quality-test-activity1.out"
	local testinput=""
	local testdirectory="A1-CountFlips"
	local testprogram="java CountFlips"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Run CountFlips)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A1-CountFlips"
	local testprogram="java CountFlips"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (Kennel)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-Kennel"
	local testprogram="Kennel.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Kennel.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-Kennel"
	local mainsrc="Kennel.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Dog.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-Kennel"
	local mainsrc="Dog.java"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (Kennel)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A2-Kennel"
	local testprogram="Kennel.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (Kennel)"
	local testoutput="quality-test-activity2.out"
	local testinput=""
	local testdirectory="A2-Kennel"
	local testprogram="java Kennel"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test(Run Kennel)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A2-Kennel"
	local testprogram="java Kennel"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################
function acceptance-test-activity3-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 3 (Bookshelf)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="A3-Bookshelf"
	local testprogram="Bookshelf.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Bookshelf.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-Bookshelf"
	local mainsrc="Bookshelf.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Book.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-Bookshelf"
	local mainsrc="Book.java"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (Bookshelf)"
	local testoutput="quality-test-activity3.out"
	local testdirectory="A3-Bookshelf"
	local testprogram="Bookshelf.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (Bookshelf)"
	local testoutput="quality-test-activity3.out"
	local testinput="n Monday"
	local testdirectory="A3-Bookshelf"
	local testprogram="java Bookshelf"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Run Bookshelf)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A3-Bookshelf"
	local testprogram="java Bookshelf"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################
function acceptance-test-activity4-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 4 (SnakeEyes)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SnakeEyes"
	local testprogram="SnakeEyes.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (SnakeEyes.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SnakeEyes"
	local mainsrc="SnakeEyes.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Die.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SnakeEyes"
	local mainsrc="Die.java"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation3() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (PairOfDice.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SnakeEyes"
	local mainsrc="PairOfDice.java"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (SnakeEyes)"
	local testoutput="quality-test-activity4.out"
	local testdirectory="A4-SnakeEyes"
	local testprogram="SnakeEyes.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (SnakeEyes)"
	local testoutput="quality-test-activity4.out"
	local testinput=""
	local testdirectory="A4-SnakeEyes"
	local testprogram="java SnakeEyes"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Run SnakeEyes)"
	local testoutput="integration-test-activity4.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A4-SnakeEyes"
	local testprogram="java SnakeEyes"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 5 Tests         #
#                                 #
###################################
function acceptance-test-activity5-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 5 (GameOfPig)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-GameOfPig"
	local testprogram="GameOfPig.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity5-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (GameOfPig.java)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-GameOfPig"
	local mainsrc="GameOfPig.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (GameOfPig)"
	local testoutput="quality-test-activity5.out"
	local testdirectory="A5-GameOfPig"
	local testprogram="GameOfPig.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (GameOfPig)"
	local testoutput="quality-test-activity5.out"
	local testinput=""
	local testdirectory="A5-GameOfPig"
	local testprogram="java GameOfPig"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity1-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity1-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity2-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity2-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity3-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity3-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "32" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity3-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity3-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity4-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=4
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity4-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "42" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity4-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity4-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "50" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity5-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity5-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "51" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity5-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "52" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# quality-test-activity5-run-check $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


