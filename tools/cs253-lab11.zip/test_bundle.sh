#!/bin/bash
# Author: Luke Hindman
# Date:  Tue 30 Mar 2021 09:51:04 AM MDT
# Description:  Test bundle for CS253-Lab11

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests       #
#                                 #
###################################

function acceptance-test-labwarmup-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="myprog -s -d /usr/bin"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="myprog -s -d /usr/bin"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labwarmup-list-current-1() {
	local verbose=$1
	local testname="Integration Test - List Current Directory (main.c)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="main.c"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-current-2() {
	local verbose=$1
	local testname="Integration Test - List Current Directory (Makefile)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="Makefile"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-current-3() {
	local verbose=$1
	local testname="Integration Test - List Current Directory (.vscode)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="\.vscode"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-usr-bin-1() {
	local verbose=$1
	local testname="Integration Test - List /usr/bin (vim.basic)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="vim.basic"
	local testdirectory="LabWarmup"
	local testprogram="myprog -d /usr/bin"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-usr-bin-2() {
	local verbose=$1
	local testname="Integration Test - List /usr/bin (bash)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="bash"
	local testdirectory="LabWarmup"
	local testprogram="myprog -d /usr/bin"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-usr-bin-3() {
	local verbose=$1
	local testname="Integration Test - List /usr/bin (.)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="^\.$"
	local testdirectory="LabWarmup"
	local testprogram="myprog -d /usr/bin"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-list-usr-bin-4() {
	local verbose=$1
	local testname="Integration Test - List /usr/bin (..)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="^\.\.$"
	local testdirectory="LabWarmup"
	local testprogram="myprog -d /usr/bin"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}
function integration-test-labwarmup-sort-sample-1() {
	local verbose=$1
	local testname="Integration Test - Sort Sample Data (/home/student)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/lw_sample1.sorted.txt"
	local testdirectory="LabWarmup"
	local testprogram="myprog -s -d ../sample1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-sort-sample-2() {
	local verbose=$1
	local testname="Integration Test - Sort Sample Data (/usr/bin)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/lw_sample2.sorted.txt"
	local testdirectory="LabWarmup"
	local testprogram="myprog -s -d ../sample2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-sort-sample-3() {
	local verbose=$1
	local testname="Integration Test - Sort Sample Data (current)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/lw_sample3.sorted.txt"
	local testdirectory="LabWarmup"
	local testprogram="myprog -s -d ../sample3"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="myprog -r -f -d ../sample1"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="myprog -r -f -d ../sample1"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-hide-hidden-1() {
	local verbose=$1
	local testname="Integration Test - Sort & Hide Hidden (/home/student)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample1.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -s -d ../sample1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-hide-hidden-2() {
	local verbose=$1
	local testname="Integration Test - Sort & Hide Hidden (/usr/bin)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample2.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -s -d ../sample2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-hide-hidden-3() {
	local verbose=$1
	local testname="Integration Test - Sort & Hide Hidden (current)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample3.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -s -d ../sample3"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-show-hidden-1() {
	local verbose=$1
	local testname="Integration Test - Sort & Show Hidden (/home/student)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample1.sorted.hidden.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -a -s -d ../sample1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-show-hidden-2() {
	local verbose=$1
	local testname="Integration Test - Sort & Show Hidden (/usr/bin)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample2.sorted.hidden.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -a -s -d ../sample2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-show-hidden-3() {
	local verbose=$1
	local testname="Integration Test - Sort & Show Hidden (current)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample3.sorted.hidden.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -a -s -d ../sample3"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-files-only-1() {
	local verbose=$1
	local testname="Integration Test - Sort & FilesOnly (/home/student)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample1.sorted.files.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -f -s -d ../sample1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-files-only-2() {
	local verbose=$1
	local testname="Integration Test - Sort & FilesOnly (/usr/bin)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample2.sorted.files.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -f -s -d ../sample2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sort-files-only-3() {
	local verbose=$1
	local testname="Integration Test - Sort & FilesOnly (current)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample3.sorted.files.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -f -s -d ../sample3"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-reverse-sort-1() {
	local verbose=$1
	local testname="Integration Test - Reverse Sort (/home/student)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample1.reverse.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -r -d ../sample1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-reverse-sort-2() {
	local verbose=$1
	local testname="Integration Test - Reverse Sort (/usr/bin)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample2.reverse.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -r -d ../sample2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-reverse-sort-3() {
	local verbose=$1
	local testname="Integration Test - Reverse Sort (current)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="../sample_output/la_sample3.reverse.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog -r -d ../sample3"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-help() {
	local verbose=$1
	local testname="Integration Test - Help Screen"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="ascending order"
	local testdirectory="LabActivity"
	local testprogram="myprog -h"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	usage
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"

elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labwarmup-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	integration-test-labwarmup-list-current-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-current-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-current-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-usr-bin-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-usr-bin-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-usr-bin-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-list-usr-bin-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-sort-sample-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-sort-sample-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-sort-sample-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi


	num_tests=10
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)
elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	integration-test-labactivity-sort-hide-hidden-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-hide-hidden-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-hide-hidden-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-show-hidden-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-show-hidden-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-show-hidden-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-files-only-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-files-only-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sort-files-only-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-reverse-sort-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-reverse-sort-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-reverse-sort-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-help $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=13

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
	echo "unknown test $testnum"
	usage
	exit 1
fi

exit ${error_count}
