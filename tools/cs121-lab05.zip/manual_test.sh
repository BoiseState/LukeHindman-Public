#!/bin/bash

cd A1-CoinFlip; make; echo -e -n "3\n" | java CoinFlip; cd ..
cd A1-CoinFlip; make; echo -e -n "5\n" | java CoinFlip; cd ..
cd A1-CoinFlip; make; echo -e -n "10\n" | java CoinFlip; cd ..

cd A2-CoinFlipV2; make; echo -e -n "3\n" | java CoinFlipV2; cd ..
cd A2-CoinFlipV2; make; echo -e -n "5\n" | java CoinFlipV2; cd ..
cd A2-CoinFlipV2; make; echo -e -n "10\n" | java CoinFlipV2; cd ..

cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..
cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..
cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..