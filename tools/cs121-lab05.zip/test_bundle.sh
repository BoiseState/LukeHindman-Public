#!/bin/bash
# Author: Luke Hindman
# Date: Wed 27 Oct 2021 11:09:12 AM MDT
# Description:  Test bundle for CS121-Lab05

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (CoinFlip)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-CoinFlip"
	local testprogram="CoinFlip.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (CoinFlip.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-CoinFlip"
	local mainsrc="CoinFlip.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (CoinFlip)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A1-CoinFlip"
	local testprogram="CoinFlip.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (CoinFlip)"
	local testoutput="quality-test-activity1.out"
	local testinput="3"
	local testdirectory="A1-CoinFlip"
	local testprogram="java CoinFlip"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (3 flips)"
	local testoutput="integration-test-activity1.out"
	local testinput="3"
	local expectedoutputfile="../sample_output/a1-3_flips.txt"
	local testdirectory="A1-CoinFlip"
	local testprogram="java CoinFlip"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (5 flips)"
	local testoutput="integration-test-activity1.out"
	local testinput="5"
	local expectedoutputfile="../sample_output/a1-5_flips.txt"
	local testdirectory="A1-CoinFlip"
	local testprogram="java CoinFlip"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (10 flips)"
	local testoutput="integration-test-activity1.out"
	local testinput="10"
	local expectedoutputfile="../sample_output/a1-10_flips.txt"
	local testdirectory="A1-CoinFlip"
	local testprogram="java CoinFlip"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (CoinFlipV2)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="CoinFlipV2.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (CoinFlipV2.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-CoinFlipV2"
	local mainsrc="CoinFlipV2.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (CoinFlipV2)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="CoinFlipV2.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (CoinFlipV2)"
	local testoutput="quality-test-activity2.out"
	local testinput="3"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="java CoinFlipV2"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (3 flips)"
	local testoutput="integration-test-activity2.out"
	local testinput="3"
	local expectedoutputfile="../sample_output/a1-3_flips.txt"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="java CoinFlipV2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (5 flips)"
	local testoutput="integration-test-activity2.out"
	local testinput="5"
	local expectedoutputfile="../sample_output/a1-5_flips.txt"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="java CoinFlipV2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (10 flips)"
	local testoutput="integration-test-activity2.out"
	local testinput="10"
	local expectedoutputfile="../sample_output/a1-10_flips.txt"
	local testdirectory="A2-CoinFlipV2"
	local testprogram="java CoinFlipV2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################
function acceptance-test-activity3-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 3 (CharacterCounter)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="A3-CharacterCounter"
	local testprogram="CharacterCounter.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (CharacterCounter.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-CharacterCounter"
	local mainsrc="CharacterCounter.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (CharacterCounter)"
	local testoutput="quality-test-activity3.out"
	local testdirectory="A3-CharacterCounter"
	local testprogram="CharacterCounter.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (CharacterCounter)"
	local testoutput="quality-test-activity3.out"
	local testinput="n Monday"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check for 'n' in \"Monday\""
	local testoutput="integration-test-activity3.out"
	local testinput="n Monday"
	local expectedoutput="1"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check for 'z' in \"Today is Monday\""
	local testoutput="integration-test-activity3.out"
	local testinput="z Today is Monday"
	local expectedoutput="0"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check for 'n' in \"It's a sunny day\""
	local testoutput="integration-test-activity3.out"
	local testinput="n It's a sunny day"
	local expectedoutput="2"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check for 'n' in \"Nobody\""
	local testoutput="integration-test-activity3.out"
	local testinput="n Nobody"
	local expectedoutput="0"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check for 'i' in \"Mississippi River!\""
	local testoutput="integration-test-activity3.out"
	local testinput="i Mississippi River!"
	local expectedoutput="5"
	local testdirectory="A3-CharacterCounter"
	local testprogram="java CharacterCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################
function acceptance-test-activity4-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 4 (MASHGame)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-MASHGame"
	local testprogram="MASHGame.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (MASHGame.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-MASHGame"
	local mainsrc="MASHGame.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (MASHGame)"
	local testoutput="quality-test-activity4.out"
	local testdirectory="A4-MASHGame"
	local testprogram="MASHGame.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (MASHGame)"
	local testoutput="quality-test-activity4.out"
	local testinput="Luke\nn\n"
	local testdirectory="A4-MASHGame"
	local testprogram="java MASHGame"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test(Play Three Times)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A3-HigherLower"
	local testprogram="java HigherLower"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 5 Tests         #
#                                 #
###################################
function acceptance-test-activity5-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 5 (Gradebook)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-Gradebook"
	local testprogram="Gradebook.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity5-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Gradebook.java)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-Gradebook"
	local mainsrc="Gradebook.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (Gradebook)"
	local testoutput="quality-test-activity5.out"
	local testdirectory="A5-Gradebook"
	local testprogram="Gradebook.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (Gradebook)"
	local testoutput="quality-test-activity5.out"
	local testinput=""
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check grade (Barney Stinson)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Barney Stinson has an A."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check grade (Robin Scherbatsky)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Robin Scherbatsky has an A."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check grade (Ted Mosby)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Ted Mosby has a B."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check grade (Lily Aldrin)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Lily Aldrin has a B."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check grade (Marshall Eriksen)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Marshall Eriksen has a C."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check grade (Gary Blauman)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Gary Blauman has an F."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check grade (Stella Zinma)"
	local testoutput="integration-test-activity5.out"
	local testinput=""
	local expectedoutput="Stella Zinman has a D."
	local testdirectory="A5-Gradebook"
	local testprogram="java Gradebook"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=5
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=5
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity3-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "32" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=7
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity4-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "42" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity4-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "50" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity5-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity5-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "51" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "52" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity5-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


