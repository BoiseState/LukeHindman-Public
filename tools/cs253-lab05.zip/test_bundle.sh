#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 08 Feb 2021 10:59:58 AM MST
# Description:  Test bundle for CS253-Lab05

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="-\n5"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="-\n5"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-percent5() {
	local verbose=$1
	local testname="Integration Test - (% x 5)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="%%\n5"
	local expectedoutput="% % % % %"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-percent3() {
	local verbose=$1
	local testname="Integration Test - (% x 3)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="%%\n3"
	local expectedoutput="% % %"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-percent1() {
	local verbose=$1
	local testname="Integration Test - (% x 1)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="%%\n1"
	local expectedoutput="%"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-hash2() {
	local verbose=$1
	local testname="Integration Test - (# x 2)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="#\n2"
	local expectedoutput="# #"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-dot4() {
	local verbose=$1
	local testname="Integration Test - (. x 4)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=".\n4"
	local expectedoutput=". . . ."
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-b6() {
	local verbose=$1
	local testname="Integration Test - (b x 6)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="b\n6"
	local expectedoutput="b b b b b b"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################


function acceptance-test-labactivity-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="5\n2\n4"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="5\n2\n4"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-check-arrow1() {
	local verbose=$1
	local testname="Integration Test - Check Arrow (5 x 2 x 4)"
	local testoutput="integration-test-labactivity.out"
	local testinput="5\n2\n4"
	local expectedoutputfile="../sample_data/arrow1.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-check-arrow2() {
	local verbose=$1
	local testname="Integration Test - Check Arrow (7 x 3 x 9)"
	local testoutput="integration-test-labactivity.out"
	local testinput="7\n3\n9"
	local expectedoutputfile="../sample_data/arrow2.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-arrow3() {
	local verbose=$1
	local testname="Integration Test - Check Arrow (2 x 1 x 2)"
	local testoutput="integration-test-labactivity.out"
	local testinput="2\n1\n2"
	local expectedoutputfile="../sample_data/arrow3.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-smallhead() {
	local verbose=$1
	local testname="Integration Test - Check Small Head (2 x 2 x [1|2|3])"
	local testoutput="integration-test-labactivity.out"
	local testinput="2\n2\n1\n2\n3"
	local expectedoutputfile="../sample_data/arrow4.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-1() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid Base Height)"
	local testoutput="integration-test-labactivity.out"
	local testinput="X\n2\n4"
	local expectedoutput="([E|e]rror)|([U|u]nrecognized input)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local status

	# Run integration test in subshell
	result=$( test-error-handling-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	status=$?
	echo "$result"
	return $status
}

function integration-test-labactivity-error-handling-2() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid Base Width)"
	local testoutput="integration-test-labactivity.out"
	local testinput="5\nX\n4"
	local expectedoutput="([E|e]rror)|([U|u]nrecognized input)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local status

	# Run integration test in subshell
	result=$( test-error-handling-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	status=$?
	echo "$result"
	return $status
}

function integration-test-labactivity-error-handling-3() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid Head Width)"
	local testoutput="integration-test-labactivity.out"
	local testinput="5\n2\nX"
	local expectedoutput="([E|e]rror)|([U|u]nrecognized input)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local status

	# Run integration test in subshell
	result=$( test-error-handling-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	status=$?
	echo "$result"
	return $status
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
    duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	#echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	integration-test-labwarmup-percent1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-percent3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-percent5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-hash2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-dot4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-b6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Completeness Tests
	integration-test-labactivity-check-arrow1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-check-arrow2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-check-arrow3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-check-smallhead $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=7
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
		echo "unknown test $testnum"
	usage
	exit 1
fi

exit ${error_count}


