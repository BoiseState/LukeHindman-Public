#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 08 Feb 2021 10:59:58 AM MST
# Description:  Test bundle for CS253-Lab04


###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? -eq 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Build Check"
	testoutput="quality-test-labwarmup.out"
	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? -ne 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="%\n5"


	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="%\n5"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	elif [ $? -ne 127 ];
	then
		echo "${testname}: passed"
		status=0
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-percent5() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (% x 5)"
	testoutput="unit-test-labwarmup.out"
	testinput="%\n5"
	expectedoutput="% % % % %"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-percent3() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (% x 3)"
	testoutput="unit-test-labwarmup.out"
	testinput="%\n3"
	expectedoutput="% % %"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-percent1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (% x 1)"
	testoutput="unit-test-labwarmup.out"
	testinput="%\n1"
	expectedoutput="%"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-hash2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (# x 2)"
	testoutput="unit-test-labwarmup.out"
	testinput="#\n2"
	expectedoutput="# #"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-dot4() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (. x 4)"
	testoutput="unit-test-labwarmup.out"
	testinput=".\n4"
	expectedoutput=". . . ."

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-splat6() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - (* x 6)"
	testoutput="unit-test-labwarmup.out"
	testinput="*\n6"
	expectedoutput="* * * * * *"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"

	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-build-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Build Check"
	testoutput="quality-test-labactivity.out"
	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? -ne 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labactivity-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="5\n2\n4"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="5\n2\n4"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	elif [ $? -ne 127 ];
	then
		echo "${testname}: passed"
		status=0
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-arrow1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Check Arrow (5 x 2 x 4)"
	testoutput="unit-test-labactivity.out"
	testinput="5\n2\n4"
	expectedoutputfile="../arrow1.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	exit_status=-1
	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	
	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		sed -i -n '/^*/p' ${testoutput}
		diff ${testoutput} ${expectedoutputfile} > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}


function unit-test-labactivity-check-arrow2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Check Arrow (7 x 3 x 9)"
	testoutput="unit-test-labactivity.out"
	testinput="7\n3\n9"
	expectedoutputfile="../arrow2.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		sed -i -n '/^*/p' ${testoutput}
		diff ${testoutput} ${expectedoutputfile} > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-arrow3() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Check Arrow (2 x 1 x 2)"
	testoutput="unit-test-labactivity.out"
	testinput="2\n1\n2"
	expectedoutputfile="../arrow3.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		sed -i -n '/^*/p' ${testoutput}
		diff ${testoutput} ${expectedoutputfile} > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-smallhead() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Check Small Head (2 x 2 x [1|2|3])"
	testoutput="unit-test-labactivity.out"
	testinput="2\n2\n1\n2\n3"
	expectedoutputfile="../arrow4.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	# Cleanup output file by remove all lines that do not contain "*"
	sed -i -n '/^*/p' ${testoutput}

	diff ${testoutput} ${expectedoutputfile}  > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	elif [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
    duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi
	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	unit-test-labwarmup-percent1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-percent3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-percent5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-hash2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-dot4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-splat6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Completeness Tests
	unit-test-labactivity-check-arrow1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-arrow2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-arrow3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-check-smallhead $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=4
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ];
then
	# Coding Journal Content Review
	unit-test-labactivity-check-gallons $verbose
	error_count=$(($error_count + $?))
else
	echo "unknown test $testnum"
fi

exit ${error_count}


