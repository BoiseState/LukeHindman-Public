#!/bin/bash
# Author: Luke Hindman
# Date: Mon 11 Oct 2021 12:56:29 PM MDT
# Description:  Test bundle for CS121-Lab04

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (LeapChecker)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-LeapChecker"
	local testprogram="LeapChecker.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (LeapChecker.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-LeapChecker"
	local mainsrc="LeapChecker.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (LeapChecker)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A1-LeapChecker"
	local testprogram="LeapChecker.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (LeapChecker)"
	local testoutput="quality-test-activity1.out"
	local testinput="2020\nn\n"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (1980)"
	local testoutput="integration-test-activity1.out"
	local testinput="1980\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (2020)"
	local testoutput="integration-test-activity1.out"
	local testinput="2020\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (1900)"
	local testoutput="integration-test-activity1.out"
	local testinput="1900\nn\n"
	local expectedoutput="is not a leap year"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (2019)"
	local testoutput="integration-test-activity1.out"
	local testinput="2019\nn\n"
	local expectedoutput="is not a leap year"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (2000)"
	local testoutput="integration-test-activity1.out"
	local testinput="2000\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="A1-LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (EvenNumberSum)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="EvenNumberSum.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (EvenNumberSum.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-EvenNumberSum"
	local mainsrc="EvenNumberSum.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (EvenNumberSum)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="EvenNumberSum.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (EvenNumberSum)"
	local testoutput="quality-test-activity1.out"
	local testinput="100\nn\n"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (100)"
	local testoutput="integration-test-activity1.out"
	local testinput="100\nn\n"
	local expectedoutput="2550"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (101)"
	local testoutput="integration-test-activity1.out"
	local testinput="101\nn\n"
	local expectedoutput="2550"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (7)"
	local testoutput="integration-test-activity1.out"
	local testinput="7\nn\n"
	local expectedoutput="12"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (10)"
	local testoutput="integration-test-activity1.out"
	local testinput="10\nn\n"
	local expectedoutput="30"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (1)"
	local testoutput="integration-test-activity1.out"
	local testinput="1\nn\n"
	local expectedoutput="greater than two"
	local testdirectory="A2-EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################
function acceptance-test-activity3-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 3 (HigherLower)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="A3-HigherLower"
	local testprogram="HigherLower.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (HigherLower.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-HigherLower"
	local mainsrc="HigherLower.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (HigherLower)"
	local testoutput="quality-test-activity3.out"
	local testdirectory="A3-HigherLower"
	local testprogram="HigherLower.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (HigherLower): skipped"
	local testoutput="quality-test-activity3.out"
	local testinput="10 30\n15 70"
	local testdirectory="A3-HigherLower"
	local testprogram="java HigherLower"
	local result
	local exit_status

	echo "$testname"
	exit_status=0
	return $exit_status
}

function integration-test-activity3-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test(Play Three Games)"
	local testoutput="integration-test-activity3.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="A3-HigherLower"
	local testprogram="java HigherLower"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################
function acceptance-test-activity4-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 4 (VowelCounter)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-VowelCounter"
	local testprogram="VowelCounter.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (VowelCounter.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-VowelCounter"
	local mainsrc="VowelCounter.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (VowelCounter)"
	local testoutput="quality-test-activity4.out"
	local testdirectory="A4-VowelCounter"
	local testprogram="VowelCounter.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (VowelCounter)"
	local testoutput="quality-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check 'a' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local expectedoutput="a*[:|=][ ]*0"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check 'e' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local expectedoutput="e*[:|=][ ]*1"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check 'i' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local expectedoutput="i*[:|=][ ]*5"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check 'o' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi Rive\nn\nr"
	local expectedoutput="o*[:|=][ ]*0"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check 'u' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local expectedoutput="u*[:|=][ ]*0"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check 'other' (Mississippi River)"
	local testoutput="integration-test-activity4.out"
	local testinput="Mississippi River\nn\n"
	local expectedoutput="11"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check 'a' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="a*[:|=][ ]*4"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-8() {
	local verbose=$1
	local testname="Integration Test - Check 'e' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="e*[:|=][ ]*7"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-9() {
	local verbose=$1
	local testname="Integration Test - Check 'i' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="i*[:|=][ ]*3"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-10() {
	local verbose=$1
	local testname="Integration Test - Check 'o' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="o*[:|=][ ]*8"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-11() {
	local verbose=$1
	local testname="Integration Test - Check 'u' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="u*[:|=][ ]*2"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-12() {
	local verbose=$1
	local testname="Integration Test - Check 'other' (Life is like a box of chocolates, you never know what you're gonna get...)"
	local testoutput="integration-test-activity4.out"
	local testinput="Life is like a box of chocolates, you never know what you're gonna get...\nn\n"
	local expectedoutput="49"
	local testdirectory="A4-VowelCounter"
	local testprogram="java VowelCounter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 5 Tests         #
#                                 #
###################################
function acceptance-test-activity5-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 5 (RockPaperScissors)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-RockPaperScissors"
	local testprogram="RockPaperScissors.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity5-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (RockPaperScissors.java)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-RockPaperScissors"
	local mainsrc="RockPaperScissors.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (RockPaperScissors)"
	local testoutput="quality-test-activity5.out"
	local testdirectory="A5-RockPaperScissors"
	local testprogram="RockPaperScissors.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (RockPaperScissors)"
	local testoutput="quality-test-activity5.out"
	local testinput="1\nn\n"
	local testdirectory="A5-RockPaperScissors"
	local testprogram="java RockPaperScissors"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Play Three Games)"
	local testoutput="integration-test-activity5.out"
	local testinput="1\nn\n"
	local expectedoutput="[win|lose]"
	local testdirectory="A5-RockPaperScissors"
	local testprogram="java RockPaperScissors"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=7
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# integration-test-activity2-output-check-5 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity3-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "32" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity3-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity4-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "42" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity4-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=14
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "50" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity5-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity5-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "51" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "52" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity5-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


