#!/bin/bash
# Author: Luke Hindman
# Date:  Fri 30 Apr 2021 12:23:01 PM MDT
# Description:  Test bundle for CS253 final project

source test_functions.sh


##############################################################
#                                                            #
#                   Acceptance Tests                         #
#                                                            #
##############################################################

function acceptance-test-project-build-myps() {
	local verbose=$1
	local testname="Acceptance Test - Build (myps)"
	local testoutput="acceptance-test-project.out"
	local testdirectory="Project"
	local testprogram="myps"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-project-min-implementation-myps() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (myps.c)"
	local testoutput="acceptance-test-project.out"
	local testdirectory="Project"
	local mainsrc="myps.c"
	local minlines=20
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-project-min-implementation-procentry() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (ProcEntry.c)"
	local testoutput="acceptance-test-project.out"
	local testdirectory="Project"
	local mainsrc="ProcEntry.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

##############################################################
#                                                            #
#                     Quality Tests                          #
#                                                            #
##############################################################

function quality-test-project-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="Project"
	local testprogram="none"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-project-run-check-myps() {
	local verbose=$1
	local testname="Quality Test - Run Check (myps)"
	local testoutput="quality-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-project-memory-check-myps() {
	local verbose=$1
	local testname="Quality Test - Memory Check (myps)"
	local testoutput="quality-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

##############################################################
#                                                            #
#                       Unit Tests                           #
#                                                            #
##############################################################

function unit-test-project-create-destroy() {
	local verbose=$1
	local testname="Unit Test - Create/Destroy ProcEntry"
	local testoutput="unit-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="mytests -t 1"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-create-from-file-destroy() {
	local verbose=$1
	local testname="Unit Test - CreateFromFile (onyx_proc/9906/stat)"
	local testoutput="unit-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="mytests -t 2"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-create-from-file-null() {
	local verbose=$1
	local testname="Unit Test - CreateFromFile (NULL)"
	local testoutput="unit-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="mytests -t 3"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-create-from-file-does-not-exist() {
	local verbose=$1
	local testname="Unit Test - CreateFromFile (Does Not Exist)"
	local testoutput="unit-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="mytests -t 4"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-create-from-file-invalid-format() {
	local verbose=$1
	local testname="Unit Test - CreateFromFile (Invalid Format)"
	local testoutput="unit-test-project.out"
	local testinput=""
	local testdirectory="Project"
	local testprogram="mytests -t 5"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function unit-test-project-print-proc-entry-1() {
	local verbose=$1
	local testname="Unit Test - PrintProcEntry (onyx_proc/9906/stat)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="9906 2 S 0 0 1 \(kworker/29:1H\) ../sample_data/onyx_proc/9906/stat"
	local testdirectory="Project"
	local testprogram="mytests -t 6"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-print-proc-entry-2() {
	local verbose=$1
	local testname="Unit Test - PrintProcEntry (onyx_proc/19070/stat)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="19070 19069 S 0 0 1 \(bash\) ../sample_data/onyx_proc/19070/stat"
	local testdirectory="Project"
	local testprogram="mytests -t 7"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-print-proc-entry-3() {
	local verbose=$1
	local testname="Unit Test - PrintProcEntry (onyx_proc/593/stat)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="593 2 S 0 0 1 \(bnxt_pf_wq\) ../sample_data/onyx_proc/593/stat"
	local testdirectory="Project"
	local testprogram="mytests -t 8"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-print-proc-entry-4() {
	local verbose=$1
	local testname="Unit Test - PrintProcEntry (onyx_proc/1/stat)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1 0 S 1 3 1 \(systemd\) ../sample_data/onyx_proc/1/stat"
	local testdirectory="Project"
	local testprogram="mytests -t 9"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-print-proc-entry-5() {
	local verbose=$1
	local testname="Unit Test - PrintProcEntry (budgie_proc/55986/stat)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="55986 2 I 0 7 1 \(kworker/u256:1-events_unbound\) ../sample_data/budgie_proc/55986/stat"
	local testdirectory="Project"
	local testprogram="mytests -t 10"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

##############################################################
#                                                            #
#               Extra Credit Unit Tests                      #
#                                                            #
##############################################################

function unit-test-project-extra-credit-0() {
	local verbose=$1
	local testname="Extra Credit - Single Space Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(hello world\) ../sample_data/test_data_ec/stat.single_space"
	local testdirectory="Project"
	local testprogram="mytests -t 30"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-1() {
	local verbose=$1
	local testname="Extra Credit - Two Spaces Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(hello beautiful world\) ../sample_data/test_data_ec/stat.two_spaces"
	local testdirectory="Project"
	local testprogram="mytests -t 31"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-2() {
	local verbose=$1
	local testname="Extra Credit - Many Spaces Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(h e l l o w o r l d\) ../sample_data/test_data_ec/stat.many_spaces"
	local testdirectory="Project"
	local testprogram="mytests -t 32"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-3() {
	local verbose=$1
	local testname="Extra Credit - Single Opening Paran Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(hello\(world\) ../sample_data/test_data_ec/stat.single_opening_paran"
	local testdirectory="Project"
	local testprogram="mytests -t 33"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-4() {
	local verbose=$1
	local testname="Extra Credit - Single Closing Paran Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(hello\)world\) ../sample_data/test_data_ec/stat.single_closing_paran"
	local testdirectory="Project"
	local testprogram="mytests -t 34"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-5() {
	local verbose=$1
	local testname="Extra Credit - Nested Parans Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(\(hello world\)\) ../sample_data/test_data_ec/stat.nested_parans"
	local testdirectory="Project"
	local testprogram="mytests -t 35"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-extra-credit-6() {
	local verbose=$1
	local testname="Extra Credit - Surrounded Words Test"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="1080 892 S 0 0 3 \(\(hello\) \(world\)\) ../sample_data/test_data_ec/stat.surrounded_words"
	local testdirectory="Project"
	local testprogram="mytests -t 36"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

##############################################################
#                                                            #
#                   Integration Tests                        #
#                                                            #
##############################################################

function integration-test-project-proc-bash() {
	local verbose=$1
	local testname="Integration Test - Looking for bash (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="bash"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-proc-systemd() {
	local verbose=$1
	local testname="Integration Test - Looking for systemd (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="systemd"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-proc-network-manager() {
	local verbose=$1
	local testname="Integration Test - Looking for NetworkManager (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="NetworkManager"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-pid-sort-onyx() {
	local verbose=$1
	local testname="Integration Test - PID Sort (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/onyx_proc_expected/myps-pid_sort.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc -p"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-cmd-sort-onyx() {
	local verbose=$1
	local testname="Integration Test - CMD Sort (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/onyx_proc_expected/myps-cmd_sort-stripped.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc -c"
	local awkfilter="'{print \$7}'"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-awk-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$awkfilter" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-zombies-only-onyx() {
	local verbose=$1
	local testname="Integration Test - Zombies Only (onyx_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/onyx_proc_expected/myps-zombie_only.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/onyx_proc -z"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-pid-sort-budgie() {
	local verbose=$1
	local testname="Integration Test - PID Sort (budgie_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/budgie_proc_expected/myps-pid_sort.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/budgie_proc -p"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-cmd-sort-budgie() {
	local verbose=$1
	local testname="Integration Test - CMD Sort (budgie_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/budgie_proc_expected/myps-cmd_sort-stripped.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/budgie_proc -c"
	local awkfilter="'{print \$7}'"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-awk-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$awkfilter" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-zombies-only-budgie() {
	local verbose=$1
	local testname="Integration Test - Zombies Only (budgie_proc)"
	local testoutput="integration-test-project.out"
	local testinputfile=""
	local expectedoutputfile="../sample_data/budgie_proc_expected/myps-zombie_only.out"
	local testdirectory="Project"
	local testprogram="myps -d ../sample_data/budgie_proc -z"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-exact-file-match-using-diff "$testname" "$testoutput" "$testinputfile" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-project-usage-help() {
	local verbose=$1
	local testname="Integration Test - Usage / Help"
	local testoutput="integration-test-project.out"
	local testinput=""
	local expectedoutput="[Z|z]ombie"
	local testdirectory="Project"
	local testprogram="myps -h"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nProject Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit Tests"
	echo -e "-t 23\tIntegration Tests"
	echo -e "-t 24\tExtra Credit Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	usage
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# Project Acceptance Tests
	acceptance-test-project-build-myps $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-project-min-implementation-myps $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-project-min-implementation-procentry $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# Project Code Quality Tests
	quality-test-project-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-project-run-check-myps $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-project-memory-check-myps $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# Project Unit Tests
	unit-test-project-create-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-create-from-file-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-create-from-file-null $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-create-from-file-does-not-exist $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-create-from-file-invalid-format $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-print-proc-entry-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-print-proc-entry-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-print-proc-entry-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-print-proc-entry-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-print-proc-entry-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi				

	num_tests=10

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "23" ]; then
	num_passed=0
	# Project Integration Tests

	integration-test-project-proc-bash $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-proc-systemd $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-proc-network-manager $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-pid-sort-onyx $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-pid-sort-budgie $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-cmd-sort-onyx $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-cmd-sort-budgie $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-zombies-only-onyx $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-zombies-only-budgie $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-project-usage-help $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=10

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "24" ]; then
	num_passed=0
	# Project Unit Tests
	unit-test-project-extra-credit-0 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-extra-credit-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-extra-credit-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# unit-test-project-extra-credit-3 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# unit-test-project-extra-credit-4 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-extra-credit-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-project-extra-credit-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi
	

	num_tests=5

	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}
