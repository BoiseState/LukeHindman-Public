#!/bin/bash
# Author: Luke Hindman
# Date: Tue 13 Sep 2022 09:18:51 AM MDT
# Description:  Test bundle for CS153-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################


function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module2-s1.txt)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="module2-s1.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 1 - File system navigation and utilities\" (1.1)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="[S|s]cenario.*1.*-.*[F|f]ile.*[S|s]ystem.*[N|n]avigation.*[A|a]nd.*[U|u]tilities"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: pwd (1.2)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="pwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: mkdir tmp (1.3)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="mkdir.*tmp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: cd tmp (1.4)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="cd tmp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: pwd (1.5)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="pwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: ls /bin (1.6)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="ls.*/bin"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity1-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: cp /bin/cp . (1.7)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="(cp.*/bin/cp)|(cp.*cp.*tmp)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: mv cp mycp (1.8)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="mv.*cp.*mycp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: cmp /bin/cp mycp (1.9)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="cmp.*mycp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: touch fakecp (1.10)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="touch.*fakecp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: cmp /bin/cp fakecp (1.11)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="cmp.*fakecp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: rm -Rf tmp (1.12)"
	local testcontentfile="module2-s1.txt"
	local expectedoutput="(rm.*[-R|-r].*tmp)|(rm.*tmp.*[-R|-r])"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################


function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module2-s2.txt)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local mainsrc="module2-s2.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 2 - System info\" (2.1)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="[S|s]cenario.*2.*-.*[S|s]ystem.*[I|i]nfo"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: whoami (2.2)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="whoami"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: who (2.3)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: w (2.4)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="w[ ]*$"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: man w (2.5)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="man.*w"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: date (2.6)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="date"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity2-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: man date (2.7)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="man.*date"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: ps (2.8)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="ps"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity2-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: man ps (2.8)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="man.*ps"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: free (2.9)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="free"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: man free (2.10)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="man free"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: nproc (2.11)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="nproc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: lscpu (2.12)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="lscpu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################


function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module2-s3.txt)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="."
	local mainsrc="module2-s3.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 3 - Text Utilities\" (3.1)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="[S|s]cenario.*3.*-.*[T|t]ext.*[U|u]tilities"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: cat /etc/passwd (3.2)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="cat.*/etc/passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: sudo cat /etc/shadow (3.3)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="cat.*/etc/shadow"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: sort /etc/passed (3.4)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="sort.*/etc/passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: grep \"root\" /etc/passwd (3.5)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="grep.*root.*/etc/passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: wc /etc/passwd (3.6)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="wc.*/etc/passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: man wc (3.7)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="man.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: wc -l /etc/passwd (3.7)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="(wc.*-l.*/etc/passwd)|(wc.*/etc/passwd.*-l)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: tail /etc/passwd (3.8)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="tail.*/etc/passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: man tail (3.9)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="man tail"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: tail -25 /etc/passwd (3.9)"
	local testcontentfile="module2-s3.txt"
	local expectedoutput="(tail.*25.*/etc/passwd)|(tail.*/etc/passwd.*25)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################


function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module2-s4.txt)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="."
	local mainsrc="module2-s4.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: ssh username@onyx.boisestate.edu (4.1)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="ssh.*onyx.boisestate.edu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 4 - Remote Console Access\" (4.1a)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*[S|s]cenario.*4.*-.*[R|r]emote.*[C|c]onsole.*[A|a]ccess"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: whoami (4.1b)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*whoami"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: who (4.1c)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: w (4.1d)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*w[ ]*$"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: date (4.1e)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*date"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: ps (4.1f)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*ps"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: free -h (4.1g)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*free.*-h"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: nproc (4.1h)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*nproc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: lscpu (4.1i)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*lscpu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: lscpu > cpu-details (4.1j)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="onyx .*lscpu.*>.*cpu-details.txt"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: scp username@onyx.boisestate.edu:cpu-details.txt . (4.2)"
	local testcontentfile="module2-s4.txt"
	local expectedoutput="scp.*@onyx.boisestate.edu:.*cpu-details.txt"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: lscpu (2.12)"
	local testcontentfile="module2-s2.txt"
	local expectedoutput="lscpu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\LabActivity Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 30\tAcceptance Tests"
	echo -e "-t 31\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 40\tAcceptance Tests"
	echo -e "-t 41\tContent Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity1-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=12
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity2-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-13 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=13
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	content-test-activity3-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=11
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity4-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=12
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


