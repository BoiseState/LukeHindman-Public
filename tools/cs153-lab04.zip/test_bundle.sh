#!/bin/bash
# Author: Luke Hindman
# Date: Mon 19 Sep 2022 01:26:45 PM MDT
# Description:  Test bundle for CS153-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################


function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module4-s1.txt)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="module4-s1.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 1 - Hacking your shell\" (1.1)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="[S|s]cenario.*1.*-.*[H|h]acking.*[Y|y]our.*[S|s]hell"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: history (1.2)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="history"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: export (1.3)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="export"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: echo \${PATH} (1.4)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="echo.*PATH"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: export PATH=\${PATH}:. (1.5)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="export.*PATH.*=.*PATH.*:"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: alias (1.6)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="alias"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: alias t='date +%r' (1.7)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="alias.*t=.*date"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: gedit ~/.bashrc (1.8)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="gedit.*bashrc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: source ~/.bashrc (1.9)"
	local testcontentfile="module4-s1.txt"
	local expectedoutput="source.*bashrc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################


function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module4-s2.txt)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local mainsrc="module4-s2.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 2 - Process Management\" (2.1)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="[S|s]cenario.*2.*-.*[P|p]rocess.*[M|m]anagement"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: sleep 30 (ctrl-c) (2.2)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="sleep.*30"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: sleep 30 (ctrl-z) (2.3)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="sleep.*30"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: ps (2.3)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="ps"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: fg (2.3)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="fg"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: ps -ef (2.4)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="ps"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: kill <pid> (2.4)"
	local testcontentfile="module4-s2.txt"
	local expectedoutput="kill"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}




###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################


function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module4-s3.txt)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="."
	local mainsrc="module4-s3.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 3 - Building with Blocks\" (3.1)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="[S|s]cenario.*3.*-.*[B|b]uilding.*[W|w]ith.*[B|b]locks"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: ssh username@onyx.boisestate.edu (3.2)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="ssh.*onyx"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: who | wc -l (3.3)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*who.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: who | grep <user> (3.4)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*who.*grep"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: who | grep <user> | wc -l (3.5)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*who.*grep.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: ps -ef | wc -l (3.6)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ps.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: ps -ef |grep <user> (3.7)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ps.*grep"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: ps -ef |grep <user> | wc -l (3.8)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ps.*grep.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: last | grep <user> (3.9)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*last.*grep"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: ls /usr/bin | wc -l (3.10)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: ls /usr/bin |grep \"mk\" (3.11)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*grep.*mk"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-12() {
	local verbose=$1
	local testname="Content Check - Expected:ls /usr/bin |grep \"mk\" | wc -l (3.12)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*grep.*mk.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: ls /home | wc -l (3.13)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-14() {
	local verbose=$1
	local testname="Content Check - Expected: ls /home |grep \"mk\" (3.14)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*grep.*mk"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-15() {
	local verbose=$1
	local testname="Content Check - Expected:ls /home |grep \"mk\" | wc -l (3.15)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*ls.*grep.*mk.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-16() {
	local verbose=$1
	local testname="Content Check - Expected: exit (3.16)"
	local testcontentfile="module4-s3.txt"
	local expectedoutput="onyx.*exit"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################


function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module4-s4.txt)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="."
	local mainsrc="module4-s4.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 4 - Text Processing\" (4.1)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="[S|s]cenario.*4.*-.*[T|t]ext.*[P|p]rocessing"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: wget https://raw.githubusercontent.com/BoiseState/CS-HU153-resources/master/activities/music-collection.csv (4.2)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="wget.*music-collection.csv"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | wc -l (4.3)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | grep 'Jimmy Buffett' (4.4)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*grep.*Jimmy"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | grep 'Jimmy Buffett' > jimmy_buffett-collection.csv (4.5)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*grep.*Jimmy.*[>].*jimmy_buffet[t]*-collection.csv"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: cat jimmy_buffett-collection.csv | wc -l (4.6)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*jimmy_buffet[t]*-collection.csv.*wc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: cat jimmy_buffett-collection.csv | sed 's/Cheeseburger/Gardenburger/g' > jimmy_buffett-vegan_collection.csv (4.7)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*jimmy_buffet[t]*-collection.csv.*sed.*s.*Cheeseburger.*Gardenburger.*[>].*csv"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | awk -F',' '{print \$1}' (4.8)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*awk.*print.*1"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | awk -F',' '{print \$1}' | sort | uniq -c (4.9)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*awk.*print.*1.*sort.*uniq"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | awk -F',' '{print \$3}' (4.10)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*awk.*print.*3"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | awk -F',' 'BEGIN{total=0} {total += \$4} END{print total}' (4.11)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat.*music-collection.csv.*awk.*BEGIN.*END"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: cat music-collection.csv | awk -F',' '{print \" : \" \$2 \" : \" \$1}' | sort | uniq -c | sort -nr | sed -n 1,5p (4.12)"
	local testcontentfile="module4-s4.txt"
	local expectedoutput="cat music-collection.csv.*awk.*sort.*uniq.*sort.*sed"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\LabActivity Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 30\tAcceptance Tests"
	echo -e "-t 31\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 40\tAcceptance Tests"
	echo -e "-t 41\tContent Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity1-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity2-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	


	num_tests=7
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	content-test-activity3-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-13 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-14 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-15 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-16 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=16
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity4-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=12
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


