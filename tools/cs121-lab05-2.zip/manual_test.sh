#!/bin/bash

echo -e -n "\n\n"
cd MASHGame; make; echo -e -n "Luke\nMASHDatabase.csv" | java MASHGame; cd ..
echo -e -n "\n\n"
cd MASHGame; make; echo -e -n "Luke\nMASHDatabase.csv" | java MASHGame; cd ..
echo -e -n "\n\n"
cd MASHGame; make; echo -e -n "Luke\nMASHDatabase.csv" | java MASHGame; cd ..