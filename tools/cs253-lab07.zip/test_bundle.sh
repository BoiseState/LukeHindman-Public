#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 01 Mar 2021 07:25:51 AM MST
# Description:  Test bundle for CS253-Lab07

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Clean Build Check"
	testoutput="quality-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="The only thing we have to fear is fear itself."
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="The only thing we have to fear is fear itself."
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-input-output() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check Basic Input/Output"
	testoutput="integration-test-labwarmup.out"
	testinput="The only thing we have to fear is fear itself."
	expectedoutput="The only thing we have to fear is fear itself."
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-check-num-chars() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check GetNumOfCharacters"
	testoutput="integration-test-labwarmup.out"
	testinput="The only thing we have to fear is fear itself."
	expectedoutput="(46|47)" # 46 if newline character was stripped, 47 if not
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-check-no-whitespace() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check OutputWithoutWhitespace"
	testoutput="integration-test-labwarmup.out"
	testinput="The only thing we have to fear is fear itself."
	expectedoutput="Theonlythingwehavetofearisfearitself."
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-build-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Clean Build Check"
	testoutput="quality-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}


function quality-test-labactivity-run-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-input-output1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Basic Input/Output"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nq\nq"
	expectedoutput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-nonwhitespace1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfNonWSCharacters"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nc\nq"
	expectedoutput="181"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-num-words1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfWords"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nw\nq"
	expectedoutput="35"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-fix-capitalization1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check FixCapitalization"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nf\nq"
	expectedoutput="We'll continue our quest in space.  There will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  Nothing ends here;  our hopes and our journeys continue!"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-replace-exclamation1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ReplaceExclamation"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\nr\nq"
	expectedoutput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue."
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-shorten-spaces1() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ShortenSpaces"
	testoutput="integration-test-labactivity.out"
	testinput="we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!\ns\nq"
	expectedoutput="we'll continue our quest in space. there will be more shuttle flights and more shuttle crews and, yes, more volunteers, more civilians, more teachers in space. nothing ends here; our hopes and our journeys continue."
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-input-output2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Basic Input/Output"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\nq\nq"
	expectedoutput="a horse!  a horse!  my kingdom for a horse!"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-nonwhitespace2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfNonWSCharacters"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\nc\nq"
	expectedoutput="33"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-num-words2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfWords"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\nw\nq"
	expectedoutput="9"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-fix-capitalization2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check FixCapitalization"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\nf\nq"
	expectedoutput="A horse!  A horse!  My kingdom for a horse!"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-replace-exclamation2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ReplaceExclamation"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\nr\nq"
	expectedoutput="a horse.  a horse.  my kingdom for a horse."
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-shorten-spaces2() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ShortenSpaces"
	testoutput="integration-test-labactivity.out"
	testinput="a horse!  a horse!  my kingdom for a horse!\ns\nq"
	expectedoutput="a horse! a horse! my kingdom for a horse!"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function integration-test-labactivity-input-output3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Basic Input/Output"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\nq\nq"
	expectedoutput="BOB"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-nonwhitespace3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfNonWSCharacters"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\nc\nq"
	expectedoutput="3"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-count-num-words3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check GetNumOfWords"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\nw\nq"
	expectedoutput="1"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-fix-capitalization3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check FixCapitalization"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\nf\nq"
	expectedoutput="BOB"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-replace-exclamation3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ReplaceExclamation"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\nr\nq"
	expectedoutput="BOB"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-shorten-spaces3() {
	verbose=$1
	testname="Integration Test - LabActivity - Check ShortenSpaces"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\ns\nq"
	expectedoutput="BOB"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-run-all3() {
	verbose=$1
	testname="Integration Test - LabActivity - Run All"
	testoutput="integration-test-labactivity.out"
	testinput="BOB\ns\nr\nf\nw\nc\nq"
	expectedoutput="3"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
	duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"
elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	echo "**Input String:** The only thing we have to fear is fear itself."

	integration-test-labwarmup-input-output $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-check-num-chars $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-check-no-whitespace $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	echo "**Input String:** we'll continue our quest in space.  there will be more shuttle flights and more shuttle crews and,  yes,  more volunteers, more civilians,  more teachers in space.  nothing ends here;  our hopes and our journeys continue!"

	integration-test-labactivity-input-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-nonwhitespace1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-num-words1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-fix-capitalization1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-replace-exclamation1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-shorten-spaces1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	echo "**Input String:** a horse!  a horse!  my kingdom for a horse!"

	integration-test-labactivity-input-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-nonwhitespace2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-num-words2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-fix-capitalization2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-replace-exclamation2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-shorten-spaces2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	echo "**Input String:** BOB"

	integration-test-labactivity-input-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-nonwhitespace3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-count-num-words3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-fix-capitalization3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-replace-exclamation3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-shorten-spaces3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=18
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ]; then
	num_passed=0

	# One-off testing
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

else
	echo "unknown test $testnum"
fi

exit ${error_count}
