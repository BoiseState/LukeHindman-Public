#!/bin/bash

cd A1-CountFlips; make; echo -e -n "" | java CountFlips; cd ..

cd A2-Kennel; make; echo -e -n "" | java Kennel; cd ..

cd A3-Bookshelf; make; echo -e -n "" | java Bookshelf; cd ..

cd A4-SnakeEyes; make; echo -e -n "" | java SnakeEyes; cd ..

cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..
cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..
cd A4-MASHGame; make; echo -e -n "Luke\n" | java MASHGame; cd ..