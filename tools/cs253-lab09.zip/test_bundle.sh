#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 01 Mar 2021 07:25:51 AM MST
# Description:  Test bundle for CS253-Lab07

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Clean Build Check"
	testoutput="quality-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Roxanne Hughes\n443-555-2864\nJuan Alberto Jr.\n410-555-9385\nRachel Phillips\n310-555-6610"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Roxanne Hughes\n443-555-2864\nJuan Alberto Jr.\n410-555-9385\nRachel Phillips\n310-555-6610"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function unit-test-labwarmup-create-destroy() {
	verbose=$1
	testname="Unit Test - Create/Destroy ContactNode"
	testoutput="unit-test-labwarmup.out"
	testinput=""
	testdirectory="LabWarmup"
	testprogram="mytests -t 1"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labwarmup-insert-after-tail() {
	verbose=$1
	testname="Unit Test - Insert ContactNode After (tail)"
	testoutput="unit-test-labwarmup.out"
	testinput=""
	testdirectory="LabWarmup"
	testprogram="mytests -t 2"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labwarmup-insert-after-middle() {
	verbose=$1
	testname="Unit Test - Insert ContactNode After (middle)"
	testoutput="unit-test-labwarmup.out"
	testinput=""
	testdirectory="LabWarmup"
	testprogram="mytests -t 3"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labwarmup-get-next-after-insert() {
	verbose=$1
	testname="Unit Test - Get Next After Insert"
	testoutput="unit-test-labwarmup.out"
	testinput=""
	testdirectory="LabWarmup"
	testprogram="mytests -t 4"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function integration-test-labwarmup-first-contact-check() {
	verbose=$1
	testname="Integration Test - Check First Contact"
	testoutput="integration-test-labwarmup.out"
	testinput="Roxanne Hughes\n443-555-2864\nJuan Alberto Jr.\n410-555-9385\nRachel Phillips\n310-555-6610"
	expectedoutput="Roxanne Hughes"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-second-contact-check() {
	verbose=$1
	testname="Integration Test - Check Second Contact"
	testoutput="integration-test-labwarmup.out"
	testinput="Roxanne Hughes\n443-555-2864\nJuan Alberto Jr.\n410-555-9385\nRachel Phillips\n310-555-6610"
	expectedoutput="Juan Alberto Jr."
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-third-contact-check() {
	verbose=$1
	testname="Integration Test - Check Third Contact"
	testoutput="integration-test-labwarmup.out"
	testinput="Roxanne Hughes\n443-555-2864\nJuan Alberto Jr.\n410-555-9385\nRachel Phillips\n310-555-6610"
	expectedoutput="Rachel Phillips"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-build-check() {
	verbose=$1
	testname="Quality Test - Clean Build Check"
	testoutput="quality-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}


function quality-test-labactivity-run-check() {
	verbose=$1
	testname="Quality Test - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\no\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	testname="Quality Test - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\no\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function unit-test-labactivity-create-destroy() {
	verbose=$1
	testname="Unit Test - Create/Destroy PlaylistNode"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 1"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-insert-after-tail() {
	verbose=$1
	testname="Unit Test - Insert PlaylistNode After (tail)"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 2"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-insert-after-middle() {
	verbose=$1
	testname="Unit Test - Insert PlaylistNode After (middle)"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 3"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-set-next-node() {
	verbose=$1
	testname="Unit Test - Set Next Node"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 4"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-set-next-null-list() {
	verbose=$1
	testname="Unit Test - Set Next Node (NULL nodeInList)"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 5"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-set-next-null-node() {
	verbose=$1
	testname="Unit Test - Set Next Node (NULL newNode)"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 6"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function unit-test-labactivity-get-next-after-insert() {
	verbose=$1
	testname="Unit Test - Get Next After Insert"
	testoutput="unit-test-labactivity.out"
	testinput=""
	testdirectory="LabActivity"
	testprogram="mytests -t 7"

	# Run quality test
	test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function integration-test-labactivity-first-song-check() {
	verbose=$1
	testname="Integration Test - Add / Output First Song Check"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\no\nq"
	expectedoutput="Peg"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-second-song-check() {
	verbose=$1
	testname="Integration Test - Add / Output Second Song Check"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\no\nq"
	expectedoutput="All For You"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-third-song-check() {
	verbose=$1
	testname="Integration Test - Add / Output Third Song Check"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\no\nq"
	expectedoutput="Canned Heat"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-total-time-check() {
	verbose=$1
	testname="Integration Test - Total Time Check"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nt\nq"
	expectedoutput="958"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-remove-song-check1() {
	verbose=$1
	testname="Integration Test - Remove Song / Total Time Check (head)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nr\nSD123\nt\nq"
	expectedoutput="721"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-remove-song-check2() {
	verbose=$1
	testname="Integration Test - Remove Song / Total Time Check (tail)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nr\nJ345\nt\nq"
	expectedoutput="628"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-remove-song-check3() {
	verbose=$1
	testname="Integration Test - Remove Song / Total Time Check (middle)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nr\nJJ234\nt\nq"
	expectedoutput="567"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-change-position-check1() {
	verbose=$1
	testname="Integration Test - Change Postion (move head)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nc\n1\n2\no\nq"
	expectedoutput=""
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-change-position-check2() {
	verbose=$1
	testname="Integration Test - Change Postion (move tail)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nc\n3\n2\no\nq"
	expectedoutput=""
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-change-position-check3() {
	verbose=$1
	testname="Integration Test - Change Postion (move to head)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nc\n2\n1\no\nq"
	expectedoutput=""
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


function integration-test-labactivity-change-position-check4() {
	verbose=$1
	testname="Integration Test - Change Postion (move to tail)"
	testoutput="integration-test-labactivity.out"
	testinput="JAMZ\na\nSD123\nPeg\nSteely Dan\n237\na\nJJ234\nAll For You\nJanet Jackson\n391\na\nJ345\nCanned Heat\nJamiroquai\n330\nc\n2\n3\no\nq"
	expectedoutput=""
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
	duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"
elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	unit-test-labwarmup-create-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-insert-after-tail $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-insert-after-middle $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-get-next-after-insert $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-first-contact-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-second-contact-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-third-contact-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=7
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	unit-test-labactivity-create-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-tail $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-middle $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-set-next-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi


	unit-test-labactivity-set-next-null-list $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-set-next-null-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-get-next-after-insert $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi


	integration-test-labactivity-first-song-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-second-song-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-third-song-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-total-time-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# integration-test-labactivity-change-position-check1 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# integration-test-labactivity-change-position-check2 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# integration-test-labactivity-change-position-check3 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	# integration-test-labactivity-change-position-check4 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-remove-song-check1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-remove-song-check2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-remove-song-check3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=14
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ]; then
	num_passed=0

	# One-off testing
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

else
	echo "unknown test $testnum"
fi

exit ${error_count}
