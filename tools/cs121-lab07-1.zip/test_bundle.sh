#!/bin/bash
# Author: Luke Hindman
# Date: Wed 27 Oct 2021 11:09:12 AM MDT
# Description:  Test bundle for CS121-Lab07

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (NumberStats)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="NumberStats"
	local testprogram="NumberStats.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (NumberStats.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="NumberStats"
	local mainsrc="NumberStats.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (NumberStats)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="NumberStats"
	local testprogram="NumberStats.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (NumberStats)"
	local testoutput="quality-test-activity1.out"
	local testinput="25\n123"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Generated Values (count:25, seed:123)"
	local testoutput="integration-test-activity1.out"
	local testinput="25\n123"
	local expectedoutput="83, 51, 77, 90, 96, 58, 35, 38, 86, 54, 40, 27, 73, 66, 38, 50, 21, 86, 55, 17, 23, 38, 37, 51, 79"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Histogram (count:25, seed:123)"
	local testoutput="integration-test-activity1.out"
	local testinput="25\n123"
	local expectedoutputfile="../sample_data/numberstats-histogram-25-123.txt"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Generated Values (count:12, seed:456)"
	local testoutput="integration-test-activity1.out"
	local testinput="12\n456"
	local expectedoutput="89, 31, 66, 38, 77, 8, 48, 75, 82, 14, 99, 65"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Histogram (count:12, seed:456)"
	local testoutput="integration-test-activity1.out"
	local testinput="12\n456"
	local expectedoutputfile="../sample_data/numberstats-histogram-12-456.txt"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-activity1-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Generated Values (count:42, seed:42)"
	local testoutput="integration-test-activity1.out"
	local testinput="42\n42"
	local expectedoutput="31, 64, 49, 85, 71, 26, 6, 19, 20, 94, 83, 3, 77, 93, 77, 33, 57, 71, 44, 10, 1, 64, 27, 14, 44, 42, 31, 59, 88, 47, 31, 57, 31, 86, 18, 28, 13, 94, 14, 65, 80, 66"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Histogram (count:42, seed:42)"
	local testoutput="integration-test-activity1.out"
	local testinput="42\n42"
	local expectedoutputfile="../sample_data/numberstats-histogram-42-42.txt"
	local testdirectory="NumberStats"
	local testprogram="java NumberStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (BubbleSorter)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="BubbleSorter"
	local testprogram="BubbleSorter.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (BubbleSorter.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="BubbleSorter"
	local mainsrc="BubbleSorter.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (BubbleSorter)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="BubbleSorter"
	local testprogram="BubbleSorter.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (BubbleSorter)"
	local testoutput="quality-test-activity1.out"
	local testinput="25\n123"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Generated Output (count:25, seed:123)"
	local testoutput="integration-test-activity2.out"
	local testinput="25\n123"
	local expectedoutput="83, 51, 77, 90, 96, 58, 35, 38, 86, 54, 40, 27, 73, 66, 38, 50, 21, 86, 55, 17, 23, 38, 37, 51, 79"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Sorted Output (count:25, seed:123)"
	local testoutput="integration-test-activity2.out"
	local testinput="25\n123"
	local expectedoutput="17, 21, 23, 27, 35, 37, 38, 38, 38, 40, 50, 51, 51, 54, 55, 58, 66, 73, 77, 79, 83, 86, 86, 90, 96"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Generated Values (count:12, seed:456)"
	local testoutput="integration-test-activity2.out"
	local testinput="12\n456"
	local expectedoutput="89, 31, 66, 38, 77, 8, 48, 75, 82, 14, 99, 65"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Sorted Values (count:12, seed:456)"
	local testoutput="integration-test-activity2.out"
	local testinput="12\n456"
	local expectedoutput="8, 14, 31, 38, 48, 65, 66, 75, 77, 82, 89, 99"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Generated Values (count:42, seed:42)"
	local testoutput="integration-test-activity2.out"
	local testinput="42\n42"
	local expectedoutput="31, 64, 49, 85, 71, 26, 6, 19, 20, 94, 83, 3, 77, 93, 77, 33, 57, 71, 44, 10, 1, 64, 27, 14, 44, 42, 31, 59, 88, 47, 31, 57, 31, 86, 18, 28, 13, 94, 14, 65, 80, 66"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Sorted Values (count:42, seed:42)"
	local testoutput="integration-test-activity2.out"
	local testinput="42\n42"
	local expectedoutput="1, 3, 6, 10, 13, 14, 14, 18, 19, 20, 26, 27, 28, 31, 31, 31, 31, 33, 42, 44, 44, 47, 49, 57, 57, 59, 64, 64, 65, 66, 71, 71, 77, 77, 80, 83, 85, 86, 88, 93, 94, 94"
	local testdirectory="BubbleSorter"
	local testprogram="java BubbleSorter"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}
###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=8
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=8
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


