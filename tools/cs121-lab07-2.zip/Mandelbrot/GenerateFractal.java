import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.awt.*;

public interface GenerateFractal {
    
    public static void main(String[] args) {

        String name = "mandelbrot";
        String type = "png";
        Boolean useColor = true;

        /* Process commandline arguments */
        if (args.length > 0 && args[0].equals("--grayscale") ){
            useColor = false;
        }

        for (int i = 0; i < args.length; i++) {
            System.out.println("[" + i + "] - " + args[i]);
        }

        HindmanVisualizer fractal = new Mandelbrot();

        BufferedImage img = new BufferedImage( fractal.getDimensions().width,fractal.getDimensions().height,BufferedImage.TYPE_INT_RGB);  
        Graphics2D g2d = img.createGraphics();  

        //Output Simulation to Graphic Object
        if (useColor) {
            drawImage(g2d, fractal.getDataset(), fractal.getColorPalette());
            name += "-color";
        } else {
            drawImage(g2d, fractal.getDataset(), null);
            name += "-gray";
        }

        //Save as Picture  
        try{
            ImageIO.write(img, type, new File(name+"."+type) );
        }catch (IOException e){
            e.printStackTrace();
        }
        //Release graphic objects  
        g2d.dispose(); 

    }


    public static void drawImage(Graphics2D pen, int[][] dataset, Color[] palette) {

        if (palette == null) {
            palette = buildGrayScalePalette();
        }
        for(int row = 0; row < dataset.length; row++) {
            for (int col = 0; col < dataset[row].length; col++) {
                int locationValue = dataset[row][col];
                
                Color locationColor;
                if (locationValue < palette.length) {
                    locationColor = palette[locationValue];
                } else {
                    locationColor = palette[palette.length-1];
                }
                
                Rectangle current = new Rectangle(col,row,1,1);
                pen.setColor(locationColor);
                pen.fill(current);
            }
        }
    }

    private static Color[] buildGrayScalePalette() {
        Color[] palette = new Color[256];

        for (int i = 0; i < 256; i++) {
            palette[i] = new Color(255-i,255-i,255-i);
        }

        return palette;
    }

}
