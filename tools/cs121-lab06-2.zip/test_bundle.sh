#!/bin/bash
# Author: Luke Hindman
# Date: Wed 06 Apr 2022 02:03:31 PM MDT
# Description:  Test bundle for CS121-Lab06

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (MonitoringStation)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="MonitoringStation"
	local testprogram="MonitoringStation.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (MonitoringStation.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="MonitoringStation"
	local mainsrc="MonitoringStation.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (MonitoringStation)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="MonitoringStation"
	local testprogram="MonitoringStation.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (MonitoringStation)"
	local testoutput="quality-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-1.tsv"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Flow Rate (glenwood-boise-1.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-1.tsv"
	local expectedoutput="226"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Station Summary (glenwood-boise-1.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-1.tsv"
	local expectedoutput="[O|o]bservations:.*1"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Flow Rate 1 (glenwood-boise-3.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-3.tsv"
	local expectedoutput="231"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-activity1-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Flow Rate 2 (glenwood-boise-3.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-3.tsv"
	local expectedoutput="249"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Flow Rate 3 (glenwood-boise-3.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-3.tsv"
	local expectedoutput="261"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Station Summary (glenwood-boise-3.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-3.tsv"
	local expectedoutput="[O|o]bservations:.*3"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-activity1-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check Station Summary (glenwood-boise-day.tsv)"
	local testoutput="integration-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River\nglenwood-boise-day.tsv"
	local expectedoutput="[O|o]bservations:.*96"
	local testdirectory="MonitoringStation"
	local testprogram="java MonitoringStationDriver"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (RiverFlowStats)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="RiverFlowStats"
	local testprogram="RiverFlowStats.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (RiverFlowStats.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="RiverFlowStats"
	local mainsrc="RiverFlowStats.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (RiverFlowStats)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="RiverFlowStats"
	local testprogram="RiverFlowStats.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (RiverFlowStats)"
	local testoutput="quality-test-activity1.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2000\nglenwood-boise-2000.tsv"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Max Flow Rate (glenwood-boise-2000.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2000\nglenwood-boise-2000.tsv"
	local expectedoutput="3870"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Min Flow Rate (glenwood-boise-2000.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2000\nglenwood-boise-2000.tsv"
	local expectedoutput="188"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Average Flow Rate (glenwood-boise-2000.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2000\nglenwood-boise-2000.tsv"
	local expectedoutput="818.5974"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Sample Count (glenwood-boise-2000.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2000\nglenwood-boise-2000.tsv"
	local expectedoutput="32153"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Max Flow Rate (glenwood-boise-2010.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2010\nglenwood-boise-2010.tsv"
	local expectedoutput="6000"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Min Flow Rate (glenwood-boise-2010.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2010\nglenwood-boise-2010.tsv"
	local expectedoutput="133"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check Average Flow Rate (glenwood-boise-2010.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2010\nglenwood-boise-2010.tsv"
	local expectedoutput="729.3648"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-8() {
	local verbose=$1
	local testname="Integration Test - Check Sample Count (glenwood-boise-2010.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2010\nglenwood-boise-2010.tsv"
	local expectedoutput="34453"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-9() {
	local verbose=$1
	local testname="Integration Test - Check Max Flow Rate (glenwood-boise-2020.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2020\nglenwood-boise-2020.tsv"
	local expectedoutput="1000"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-10() {
	local verbose=$1
	local testname="Integration Test - Check Min Flow Rate (glenwood-boise-2020.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2020\nglenwood-boise-2020.tsv"
	local expectedoutput="168"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-11() {
	local verbose=$1
	local testname="Integration Test - Check Average Flow Rate (glenwood-boise-2020.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2020\nglenwood-boise-2020.tsv"
	local expectedoutput="471.6461"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-12() {
	local verbose=$1
	local testname="Integration Test - Check Sample Count (glenwood-boise-2020.tsv)"
	local testoutput="integration-test-activity2.out"
	local testinput="13206000\nGlenwood Bridge on Boise River - 2020\nglenwood-boise-2020.tsv"
	local expectedoutput="35135"
	local testdirectory="RiverFlowStats"
	local testprogram="java RiverFlowStats"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=14
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


