#!/bin/bash
# Author: Luke Hindman
# Date:  Tue 30 Mar 2021 09:51:04 AM MDT
# Description:  Test bundle for CS253-Lab10

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-song() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Song.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="Song.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="Luke"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 915"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="Luke"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 915"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-create-destroy() {
	local verbose=$1
	local testname="Unit Test - Create/Destroy Song"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 1"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-create-null-artist() {
	local verbose=$1
	local testname="Unit Test - Create Song (NULL Artist)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 2"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-create-null-album() {
	local verbose=$1
	local testname="Unit Test - Create Song (NULL Album)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 3"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-create-null-title() {
	local verbose=$1
	local testname="Unit Test - Create Song (NULL Title)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 4"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-create-neg-duration() {
	local verbose=$1
	local testname="Unit Test - Create Song (Negative Duration)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 5"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-compare-shorter() {
	local verbose=$1
	local testname="Unit Test - Compare Song (Shorter First)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 6"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-compare-longer() {
	local verbose=$1
	local testname="Unit Test - Compare Song (Longer First)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 7"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-compare-equal() {
	local verbose=$1
	local testname="Unit Test - Compare Song (Equal Length)"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 8"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labwarmup-print-song() {
	local verbose=$1
	local testname="Unit Test - Print Song"
	local testoutput="unit-test-labwarmup.out"
	local testinput=""
	local expectedoutput="Dreamline"
	local testdirectory="LabWarmup"
	local testprogram="mytests -t 9"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-loaded-songs-1() {
	local verbose=$1
	local testname="Integration Test - Loaded Songs (1)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="1 [S|s]ong"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-display-songs-1() {
	local verbose=$1
	local testname="Integration Test - Display Songs (1)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="Falling In Love"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 1"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-loaded-songs-2() {
	local verbose=$1
	local testname="Integration Test - Loaded Songs (2)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="2 [S|s]ong"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-display-songs-2() {
	local verbose=$1
	local testname="Integration Test - Display Songs (2)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="Hole In My Soul"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 2"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-loaded-songs-100() {
	local verbose=$1
	local testname="Integration Test - Loaded Songs (100)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="100 [S|s]ong"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 100"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-display-songs-100() {
	local verbose=$1
	local testname="Integration Test - Display Songs (100)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="Avant Garden"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 100"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-loaded-songs-915() {
	local verbose=$1
	local testname="Integration Test - Loaded Songs (915)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="915 [S|s]ong"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 915"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-display-songs-915() {
	local verbose=$1
	local testname="Integration Test - Display Songs (915)"
	local testoutput="integration-test-labwarmup.out"
	local testinput=""
	local expectedoutput="A Self-Made Man"
	local testdirectory="LabWarmup"
	local testprogram="myprog music-collection.csv 915"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-student() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (Student.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="Student.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="Luke"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xl.csv"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="Luke"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xl.csv"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-destroy() {
	local verbose=$1
	local testname="Unit Test - Create/Destroy Student"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 1"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-null-lastname() {
	local verbose=$1
	local testname="Unit Test - Create Student (NULL Lastname)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 2"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-null-first() {
	local verbose=$1
	local testname="Unit Test - Create Student (NULL Firstname)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 3"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-neg-id() {
	local verbose=$1
	local testname="Unit Test - Create Student (Negative ID)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 4"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-neg-score() {
	local verbose=$1
	local testname="Unit Test - Create Student (Negative Score)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 5"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-compare-lesser() {
	local verbose=$1
	local testname="Unit Test - Compare Student (Lesser Score First)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 6"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-compare-greater() {
	local verbose=$1
	local testname="Unit Test - Compare Student (Greater Score First)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 7"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-compare-equal() {
	local verbose=$1
	local testname="Unit Test - Compare Student (Equal Scores)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 8"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function unit-test-labactivity-print-student() {
	local verbose=$1
	local testname="Unit Test - Print Student"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="Lily Aldrin \(1413\) has a B- \(82\)"
	local testdirectory="LabActivity"
	local testprogram="mytests -t 9"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-loaded-students-gradebook() {
	local verbose=$1
	local testname="Integration Test - Loaded Students (gradebook.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="7 [S|s]tudent"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-display-students-gradebook() {
	local verbose=$1
	local testname="Integration Test - Display Students (gradebook.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="Ted Mosby \(6003\) has a A\+ \(103\)"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sorted-students-gradebook() {
	local verbose=$1
	local testname="Integration Test - Sorted Students (gradebook.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="gradebook.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-loaded-students-gradebook-xl() {
	local verbose=$1
	local testname="Integration Test - Loaded Students (gradebook-xl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="1000 [S|s]tudent"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-display-students-gradebook-xl() {
	local verbose=$1
	local testname="Integration Test - Display Students (gradebook-xl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="Rocio Cooke \(110630628\) has a A\+ \(107\)"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sorted-students-gradebook-xl() {
	local verbose=$1
	local testname="Integration Test - Sorted Students (gradebook-xl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="gradebook-xl.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-loaded-students-gradebook-xxl() {
	local verbose=$1
	local testname="Integration Test - Loaded Students (gradebook-xxl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	# local expectedoutput="([L|l]oaded|[A|a]dded) 5000"
	local expectedoutput="5000 [S|s]tudent"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xxl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-display-students-gradebook-xxl() {
	local verbose=$1
	local testname="Integration Test - Display Students (gradebook-xxl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="Madeline Jefferson \(110619265\) has a A\+ \(105\)"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xxl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-sorted-students-gradebook-xxl() {
	local verbose=$1
	local testname="Integration Test - Sorted Students (gradebook-xxl.csv)"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutputfile="gradebook-xxl.sorted.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog gradebook-xxl.csv"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}


###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	usage
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"

elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labwarmup-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-song $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	unit-test-labwarmup-create-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-create-null-artist $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-create-null-album $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-create-null-title $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-create-neg-duration $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-compare-shorter $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-compare-longer $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-compare-equal $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labwarmup-print-song $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-loaded-songs-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-display-songs-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-loaded-songs-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-display-songs-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-loaded-songs-100 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-display-songs-100 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-loaded-songs-915 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-display-songs-915 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=17
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)
elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-student $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	unit-test-labactivity-create-destroy $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-null-lastname $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-null-first $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-neg-id $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-neg-score $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-compare-lesser $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-compare-greater $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-compare-equal $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-print-student $verbose
#	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-loaded-students-gradebook $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-display-students-gradebook $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sorted-students-gradebook $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-loaded-students-gradebook-xl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-display-students-gradebook-xl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sorted-students-gradebook-xl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-loaded-students-gradebook-xxl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-display-students-gradebook-xxl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-sorted-students-gradebook-xxl $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=9
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}
