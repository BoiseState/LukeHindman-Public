#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 01 Mar 2021 07:25:51 AM MST
# Description:  Test bundle for CS253-Lab07

source test_functions.sh

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity-build() {
	local verbose=$1
	local testname="Acceptance Test - Build"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-datanode() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (DataNode.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="DataNode.c"
	local minlines=10
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="Luke"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="Luke"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function unit-test-labactivity-create-destroy() {
	local verbose=$1
	local testname="Unit Test - Create/Destroy DataNode"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 1"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-large-string() {
	local verbose=$1
	local testname="Unit Test - Create DataNode (Large String)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 2"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-create-null() {
	local verbose=$1
	local testname="Unit Test - Create NULL DataNode"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 3"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-insert-after-node() {
	local verbose=$1
	local testname="Unit Test - Insert DataNode After (head)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 4"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function unit-test-labactivity-insert-after-middle() {
	local verbose=$1
	local testname="Unit Test - Insert DataNode After (middle)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 5"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-insert-after-null-list() {
	local verbose=$1
	local testname="Unit Test - Insert DataNode After (NULL list)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 6"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-insert-after-null-node() {
	local verbose=$1
	local testname="Unit Test - Insert DataNode After (NULL newNode)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 7"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function unit-test-labactivity-set-next-node() {
	local verbose=$1
	local testname="Unit Test - Set Next Node"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 8"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-set-next-null-list() {
	local verbose=$1
	local testname="Unit Test - Set Next Node (NULL nodeInList)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 9"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-set-next-null-node() {
	local verbose=$1
	local testname="Unit Test - Set Next Node (NULL newNode)"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 10"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-get-next-after-insert() {
	local verbose=$1
	local testname="Unit Test - Get Next After Insert"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 11"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-get-next-null() {
	local verbose=$1
	local testname="Unit Test - Get Next NULL"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 12"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-print-data-node() {
	local verbose=$1
	local testname="Unit Test - Print DataNode"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="Red Sector A"
	local testdirectory="LabActivity"
	local testprogram="mytests -t 13"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-build-destroy-data-list() {
	local verbose=$1
	local testname="Unit Test - Build/Destroy Data List"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 14"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-get-data-list-size() {
	local verbose=$1
	local testname="Unit Test - Get Data List Size"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 15"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-verify-data-list-contents() {
	local verbose=$1
	local testname="Unit Test - Verify Data List Contents"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 16"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-print-data-list() {
	local verbose=$1
	local testname="Unit Test - Print Data List"
	local testoutput="integration-test-labactivity.out"
	local testinput=""
	local expectedoutput="mansion, apartment, shack, house"
	local testdirectory="LabActivity"
	local testprogram="mytests -t 17"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-labactivity-get-random-data-node() {
	local verbose=$1
	local testname="Unit Test - Get Random DataNode"
	local testoutput="unit-test-labactivity.out"
	local testinput=""
	local testdirectory="LabActivity"
	local testprogram="mytests -t 18"
	local result
	local exit_status

	# Run unit test in subshell
	result=$( test-run-unit-test "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-run-mash() {
	local verbose=$1
	local testname="Integration Test - Run M.A.S.H. for Luke"
	local testoutput="integration-test-labactivity.out"
	local testinput="Luke"
	local expectedoutput="Luke"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-datanode $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	unit-test-labactivity-create-destroy $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-large-string $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-create-null $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-middle $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-null-list $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-insert-after-null-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-set-next-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-set-next-null-list $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-set-next-null-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-get-next-after-insert $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-get-next-null $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-print-data-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-build-destroy-data-list $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-get-data-list-size $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-verify-data-list-contents $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-print-data-list $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	unit-test-labactivity-get-random-data-node $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-run-mash $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=19
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ]; then
	num_passed=0

	# One-off testing
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

else
	echo "unknown test $testnum"
fi

exit ${error_count}
