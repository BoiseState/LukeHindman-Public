/* 
 * File: mytests.c
 * Author: Luke Hindman
 * Date: Tue 30 Mar 2021 09:51:04 AM MDT
 * Description: Unit tests for Student object in playlist activity
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>

#include "Student.h"

#define UNUSED(x) (void)(x)
#define DISP_MSG(MSG)                                \
   if (write(STDOUT_FILENO, MSG, strlen(MSG)) == -1) \
      perror("write");

/* Define error handler */
static void handler(int sig, siginfo_t *si, void *unused)
{
   UNUSED(sig);
   UNUSED(unused);
   if (si->si_signo == SIGSEGV)
   {
      DISP_MSG("failed (segfault)\n")
      exit(1);
   }
}

int testCreateDestroy(void)
{
   char testName[] = "Unit Test - Create/Destroy Student:";
   Student *testNode = CreateStudent("Mosby","Ted",6003, 103);
   if (testNode == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
   DestroyStudent(testNode);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateNullLastname(void)
{
   char testName[] = "Unit Test - Create Student (NULL Lastname):";
   Student *testNode = CreateStudent(NULL,"Ted",6003, 103);
   if (testNode == NULL)
   {
      fprintf(stderr, "%s passed\n", testName);
      return 0;
   }
   else
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
}

int testCreateNullFirstname(void)
{
   char testName[] = "Unit Test - Create Student (NULL FirstName):";
   Student *testNode = CreateStudent("Mosby", NULL,6003, 103);
   if (testNode == NULL)
   {
      fprintf(stderr, "%s passed\n", testName);
      return 0;
   }
   else
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
}

int testCreateNegID(void)
{
   char testName[] = "Unit Test - Create Student (Negative ID):";
   Student *testNode = CreateStudent("Mosby","Ted",-1, 103);
   if (testNode == NULL)
   {
      fprintf(stderr, "%s passed\n", testName);
      return 0;
   }
   else
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
}

int testCreateNegScore(void)
{
   char testName[] = "Unit Test - Create Student (Negative Score):";
   Student *testNode = CreateStudent("Mosby","Ted",6003, -1);
   if (testNode == NULL)
   {
      fprintf(stderr, "%s passed\n", testName);
      return 0;
   }
   else
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
}

int testCompareStudentsLesser(void)
{
   char testName[] = "Unit Test - Compare Students (Lesser Score First):";
   Student *student1 = CreateStudent("Aldrin","Lily",1413, 82);
   if (student1 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   Student *student2 = CreateStudent("Mosby","Ted",6003, 103);
   if (student2 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   int rc = CompareStudents(&student1, &student2);
   if (rc >= 0)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   DestroyStudent(student1);
   DestroyStudent(student2);

   fprintf(stderr, "%s passed\n", testName);
   return 0;
}


int testCompareStudentsGreater(void)
{
   char testName[] = "Unit Test - Compare Students (Greater Score First):";
   Student *student1 = CreateStudent("Aldrin","Lily",1413, 82);
   if (student1 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   Student *student2 = CreateStudent("Mosby","Ted",6003, 103);
   if (student2 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   int rc = CompareStudents(&student2, &student1);
   if (rc <= 0)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   DestroyStudent(student1);
   DestroyStudent(student2);

   fprintf(stderr, "%s passed\n", testName);
   return 0;
}


int testCompareStudentsEqual(void)
{
   char testName[] = "Unit Test - Compare Students (Equal Score):";
   Student *student1 = CreateStudent("Aldrin","Lily",1413, 82);
   if (student1 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   int rc = CompareStudents(&student1, &student1);
   if (rc != 0)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }

   DestroyStudent(student1);

   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testPrintStudent(void)
{

   char testName[] = "Unit Test - Print Student:";

   Student *student1 = CreateStudent("Aldrin","Lily",1413, 82);
   if (student1 == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
   printf("%s - Test Output:\n", testName);
   PrintStudent(student1);

   DestroyStudent(student1);
   return 0;
}

int runall(void)
{

   int status = 0;
   status += testCreateDestroy();
   status += testCreateNullLastname();
   status += testCreateNullFirstname();
   status += testCreateNegID();
   status += testCreateNegScore();
   status += testCompareStudentsLesser();
   status += testCompareStudentsGreater();
   status += testCompareStudentsEqual();
   status += testPrintStudent();

   return status;
}

void setup_signal_handling(void)
{
   /* Setup signal handling to catch segfault */
   struct sigaction sa;
   sa.sa_flags = SA_SIGINFO;
   sigemptyset(&sa.sa_mask);
   sa.sa_sigaction = handler;
   if (sigaction(SIGSEGV, &sa, NULL) == -1)
      perror("sigaction");
}

int main(int argc, char *argv[])
{
   int status = 0;

   if (argc == 1)
   {
      status = runall();
   }
   else if (argc == 3)
   {
      int test_num = atoi(argv[2]);

      setup_signal_handling();

      switch (test_num)
      {
      case 1:
         /* Safe Path */
         status = testCreateDestroy();
         break;
      case 2:
         /* Safe Path */
         status = testCreateNullLastname();
         break;
      case 3:
         /* Safe Path */
         status = testCreateNullFirstname();
         break;
      case 4:
         /* Safe Path */
         status = testCreateNegID();
         break;
      case 5:
         /* Safe Path */
         status = testCreateNegScore();
         break;
      case 6:
         /* Invalid Test*/
         status = testCompareStudentsLesser();
         break;
      case 7:
         /* Safe Path */
         status = testCompareStudentsGreater();
         break;
      case 8:
         /* Safe Path */
         status = testCompareStudentsEqual();
         break;
      case 9:
         /* Safe Path */
         status += testPrintStudent();
         break;
      default:
         /* Unknown test selection */
         printf("Invalid test specified\n");
         printf("usage: %s [-t <test num>]\n", argv[0]);
         exit(1);
         break;
      }
   } 
   else
   {
      printf("usage: %s [-t <test num>]\n", argv[0]);
      exit(1);
   }
   

   return status;
}

