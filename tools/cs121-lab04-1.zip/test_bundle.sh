#!/bin/bash
# Author: Luke Hindman
# Date: Mon 11 Oct 2021 12:56:29 PM MDT
# Description:  Test bundle for CS121-Lab04

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build (LeapChecker)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="LeapChecker"
	local testprogram="LeapChecker.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (LeapChecker.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="LeapChecker"
	local mainsrc="LeapChecker.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (LeapChecker)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="LeapChecker"
	local testprogram="LeapChecker.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (LeapChecker)"
	local testoutput="quality-test-activity1.out"
	local testinput="2020\nn\n"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (1980)"
	local testoutput="integration-test-activity1.out"
	local testinput="1980\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (2020)"
	local testoutput="integration-test-activity1.out"
	local testinput="2020\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (1900)"
	local testoutput="integration-test-activity1.out"
	local testinput="1900\nn\n"
	local expectedoutput="is not a leap year"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (2019)"
	local testoutput="integration-test-activity1.out"
	local testinput="2019\nn\n"
	local expectedoutput="is not a leap year"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (2000)"
	local testoutput="integration-test-activity1.out"
	local testinput="2000\nn\n"
	local expectedoutput="is a leap year"
	local testdirectory="LeapChecker"
	local testprogram="java LeapChecker"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build (EvenNumberSum)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="EvenNumberSum"
	local testprogram="EvenNumberSum.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (EvenNumberSum.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="EvenNumberSum"
	local mainsrc="EvenNumberSum.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (EvenNumberSum)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="EvenNumberSum"
	local testprogram="EvenNumberSum.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (EvenNumberSum)"
	local testoutput="quality-test-activity1.out"
	local testinput="100\nn\n"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (100)"
	local testoutput="integration-test-activity1.out"
	local testinput="100\nn\n"
	local expectedoutput="2550"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (101)"
	local testoutput="integration-test-activity1.out"
	local testinput="101\nn\n"
	local expectedoutput="2550"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (7)"
	local testoutput="integration-test-activity1.out"
	local testinput="7\nn\n"
	local expectedoutput="12"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (10)"
	local testoutput="integration-test-activity1.out"
	local testinput="10\nn\n"
	local expectedoutput="30"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (1)"
	local testoutput="integration-test-activity1.out"
	local testinput="1\nn\n"
	local expectedoutput="greater than two"
	local testdirectory="EvenNumberSum"
	local testprogram="java EvenNumberSum"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=7
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# integration-test-activity2-output-check-5 $verbose
	# if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


