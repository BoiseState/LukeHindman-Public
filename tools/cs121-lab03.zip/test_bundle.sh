#!/bin/bash
# Author: Luke Hindman
# Date: Tue 28 Sep 2021 06:56:22 PM MDT
# Description:  Test bundle for CS121-Lab03

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (AccountGenerator)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-AccountGenerator"
	local testprogram="AccountGenerator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (AccountGenerator.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A1-AccountGenerator"
	local mainsrc="AccountGenerator.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (AccountGenerator)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A1-AccountGenerator"
	local testprogram="AccountGenerator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (AccountGenerator)"
	local testoutput="quality-test-activity1.out"
	local testinput="Luke\nHindman"
	local testdirectory="A1-AccountGenerator"
	local testprogram="java AccountGenerator"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (Luke Hindman)"
	local testoutput="integration-test-activity1.out"
	local testinput="Luke\nHindman"
	local expectedoutput="lhindm[0-9][0-9]"
	local testdirectory="A1-AccountGenerator"
	local testprogram="java AccountGenerator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (Grace Hopper)"
	local testoutput="integration-test-activity1.out"
	local testinput="Grace\nHopper"
	local expectedoutput="ghoppe[0-9][0-9]"
	local testdirectory="A1-AccountGenerator"
	local testprogram="java AccountGenerator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (Margaret Hamilton)"
	local testoutput="integration-test-activity1.out"
	local testinput="Margaret\nHamilton"
	local expectedoutput="mhamil[0-9][0-9]"
	local testdirectory="A1-AccountGenerator"
	local testprogram="java AccountGenerator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (PhoneNumbers)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="PhoneNumbers.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (PhoneNumbers.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A2-PhoneNumbers"
	local mainsrc="PhoneNumbers.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (PhoneNumbers)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="PhoneNumbers.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (PhoneNumbers)"
	local testoutput="quality-test-activity1.out"
	local testinput=""
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Output Check (Basic Formatting)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-9]{3}-[0-9]{3}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Area Code)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-7]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Area Code)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-7]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}
function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Area Code)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-7]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Prefix Code))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-9]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Prefix Code))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-9]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Output Check (Random Prefix Code))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput="[0-9]{3}-[0-7][0-9]{2}-[0-9]{3}"
	local testdirectory="A2-PhoneNumbers"
	local testprogram="java PhoneNumbers"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################
function acceptance-test-activity3-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 3 (DistanceCalculator)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="DistanceCalculator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (DistanceCalculator.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="A3-DistanceCalculator"
	local mainsrc="DistanceCalculator.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (DistanceCalculator)"
	local testoutput="quality-test-activity3.out"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="DistanceCalculator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity3-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (DistanceCalculator)"
	local testoutput="quality-test-activity3.out"
	local testinput="10 30\n15 70"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check First Coordinate (10 30 15 70)"
	local testoutput="integration-test-activity3.out"
	local testinput="10 30\n15 70"
	local expectedoutput="(10,[ ]*30)"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Second Coordinate (10 30 15 70)"
	local testoutput="integration-test-activity3.out"
	local testinput="10 30\n15 70"
	local expectedoutput="(15,[ ]*70)"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Distance (10 30 15 70)"
	local testoutput="integration-test-activity3.out"
	local testinput="10 30\n15 70"
	local expectedoutput="40.3112887"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Distance (0 1 1 0)"
	local testoutput="integration-test-activity3.out"
	local testinput="0 1\n1 0"
	local expectedoutput="1.4142135"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Distance (0 0 1 1)"
	local testoutput="integration-test-activity3.out"
	local testinput="0 0\n1 1"
	local expectedoutput="1.4142135623"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Distance (1 0 0 1)"
	local testoutput="integration-test-activity3.out"
	local testinput="1 0\n0 1"
	local expectedoutput="1.4142135623"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check Distance (1 1 0 0)"
	local testoutput="integration-test-activity3.out"
	local testinput="1 1\n0 0"
	local expectedoutput="1.4142135623"
	local testdirectory="A3-DistanceCalculator"
	local testprogram="java DistanceCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################
function acceptance-test-activity4-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 4 (SphereCalculator)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SphereCalculator"
	local testprogram="SphereCalculator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (SphereCalculator.java)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="A4-SphereCalculator"
	local mainsrc="SphereCalculator.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (SphereCalculator)"
	local testoutput="quality-test-activity4.out"
	local testdirectory="A4-SphereCalculator"
	local testprogram="SphereCalculator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity4-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (SphereCalculator)"
	local testoutput="quality-test-activity4.out"
	local testinput="150"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Volume (r = 150)"
	local testoutput="integration-test-activity4.out"
	local testinput="150"
	local expectedoutput="[V|v]olume.*:[ ]*14137166.9412"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Surface Area (r = 150)"
	local testoutput="integration-test-activity4.out"
	local testinput="150"
	local expectedoutput="[A|a]rea.*:[ ]*282743.3388"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Volume (r = 723)"
	local testoutput="integration-test-activity4.out"
	local testinput="723"
	local expectedoutput="[V|v]olume.*:[ ]*1583082329.1145"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Surface Area (r = 723)"
	local testoutput="integration-test-activity4.out"
	local testinput="723"
	local expectedoutput="[A|a]rea.*:[ ]*6568806.3449"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Volume (r = 16)"
	local testoutput="integration-test-activity4.out"
	local testinput="16"
	local expectedoutput="[V|v]olume.*:[ ]*17157.2847"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Surface Area (r = 16)"
	local testoutput="integration-test-activity4.out"
	local testinput="16"
	local expectedoutput="[A|a]rea.*:[ ]*3216.9909"
	local testdirectory="A4-SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



###################################
#                                 #
#        Activity 5 Tests         #
#                                 #
###################################
function acceptance-test-activity5-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 5 (TriangleCalculator)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="TriangleCalculator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity5-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (TriangleCalculator.java)"
	local testoutput="acceptance-test-activity5.out"
	local testdirectory="A5-TriangleCalculator"
	local mainsrc="TriangleCalculator.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (TriangleCalculator)"
	local testoutput="quality-test-activity5.out"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="TriangleCalculator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity5-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (TriangleCalculator)"
	local testoutput="quality-test-activity5.out"
	local testinput="10\n11\n12"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Area (10 11 12)"
	local testoutput="integration-test-activity5.out"
	local testinput="10\n11\n12"
	local expectedoutput="[A|a]rea.*:[ ]*51.521"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Area (100 110 120)"
	local testoutput="integration-test-activity5.out"
	local testinput="100\n110\n120"
	local expectedoutput="[A|a]rea.*:[ ]*5152.123"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Area (3 4 5)"
	local testoutput="integration-test-activity5.out"
	local testinput="3\n4\n5"
	local expectedoutput="[A|a]rea.*:[ ]*6"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity5-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Area (17 23 37)"
	local testoutput="integration-test-activity5.out"
	local testinput="17\n23\n37"
	local expectedoutput="[A|a]rea.*:[ ]*138.727"
	local testdirectory="A5-TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=5
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-activity3-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "32" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity3-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity3-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity3-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity3-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity4-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "42" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity4-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity4-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity4-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity4-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=8
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "50" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity5-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity5-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "51" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "52" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity5-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity5-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity5-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity5-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=6
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


