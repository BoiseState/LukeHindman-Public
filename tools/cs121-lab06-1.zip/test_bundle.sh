#!/bin/bash
# Author: Luke Hindman
# Date: Wed 27 Oct 2021 11:09:12 AM MDT
# Description:  Test bundle for CS121-Lab05

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (FlowSampleEntry)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="FlowSampleEntry"
	local testprogram="FlowSampleEntry.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (FlowSampleEntry.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="FlowSampleEntry"
	local mainsrc="FlowSampleEntry.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (FlowSampleEntry)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="FlowSampleEntry"
	local testprogram="FlowSampleEntry.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (FlowSampleEntry)"
	local testoutput="quality-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Output (Agency)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="USGS"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Output (Site Number)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="13206000"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Output (Timestamp)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="Thu 30 Dec 2021 02:30:00 PM MST"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Output (UTC Timestamp)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="Thu 30 Dec 2021 09:30:00 PM UTC"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Output (Flow Rate)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="226"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Output (Qualification Code)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutput="P"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check Output (Sample Summary)"
	local testoutput="integration-test-activity1.out"
	local testinput="USGS\n13206000\n2021-12-30 14:30\nMST\n226\nP"
	local expectedoutputfile="../sample_data/sample_summary-1.txt"
	local testdirectory="FlowSampleEntry"
	local testprogram="java FlowSampleEntry"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (FlowSampleParser)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="FlowSampleParser"
	local testprogram="FlowSampleParser.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (FlowSampleParser.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="FlowSampleParser"
	local mainsrc="FlowSampleParser.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (FlowSampleParser)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="FlowSampleParser"
	local testprogram="FlowSampleParser.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check (FlowSampleParser)"
	local testoutput="quality-test-activity1.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-1() {
	local verbose=$1
	local testname="Integration Test - Check Output (Agency)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="USGS"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-2() {
	local verbose=$1
	local testname="Integration Test - Check Output (Site Number)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="13206000"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-3() {
	local verbose=$1
	local testname="Integration Test - Check Output (Timestamp)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="Thu 30 Dec 2021 02:30:00 PM MST"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-4() {
	local verbose=$1
	local testname="Integration Test - Check Output (UTC Timestamp)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="Thu 30 Dec 2021 09:30:00 PM UTC"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-5() {
	local verbose=$1
	local testname="Integration Test - Check Output (Flow Rate)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="226"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-6() {
	local verbose=$1
	local testname="Integration Test - Check Output (Qualification Code)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutput="P"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-output-check-7() {
	local verbose=$1
	local testname="Integration Test - Check Output (Sample Summary)"
	local testoutput="integration-test-activity2.out"
	local testinput="USGS\t13206000\t2021-12-30 14:30\tMST\t226\tP"
	local expectedoutputfile="../sample_data/sample_summary-1.txt"
	local testdirectory="FlowSampleParser"
	local testprogram="java FlowSampleParser"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity1-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-activity2-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity2-output-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-output-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi



	num_tests=9
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


