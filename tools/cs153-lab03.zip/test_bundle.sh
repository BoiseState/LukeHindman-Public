#!/bin/bash
# Author: Luke Hindman
# Date: Mon 19 Sep 2022 01:26:45 PM MDT
# Description:  Test bundle for CS153-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################


function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module3-s1.txt)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="module3-s1.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 1 - Scavenger Hunt Linux Style\" (1.1)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="[S|s]cenario.*1.*-.*[S|s]cavenger.*[H|h]unt.*[L|l]inux.*[S|s]tyle"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: pwd (1.2)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="pwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: which cp (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*cp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: which mv (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*mv"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: which ls (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*ls"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: which cd (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*cd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: which echo (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*echo"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: which pwd (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*pwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: which touch (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*touch"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: which cat (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*cat"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: which which (1.3)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="which.*which"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: cd /usr/bin (1.4)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="cd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: du (1.5)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="du"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-14() {
	local verbose=$1
	local testname="Content Check - Expected: rm cp (1.6)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="rm.*cp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-14() {
	local verbose=$1
	local testname="Content Check - Expected: ls -l (1.7)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="ls.*-l"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-15() {
	local verbose=$1
	local testname="Content Check - Expected: cd /etc (1.8)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="cd.*etc"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-16() {
	local verbose=$1
	local testname="Content Check - Expected: ls -l (1.8)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="ls.*-l"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-17() {
	local verbose=$1
	local testname="Content Check - Expected: ls -l /etc/passwd (1.9)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="ls.*-l.*passwd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-18() {
	local verbose=$1
	local testname="Content Check - Expected: ls -l /etc/passwd (1.10)"
	local testcontentfile="module3-s1.txt"
	local expectedoutput="ls.*-l.*shadow"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}




###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################


function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module3-s2.txt)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local mainsrc="module3-s2.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 2 - Linux File System Lockdown\" (2.1)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="[S|s]cenario.*2.*-.*[L|l]inux.*[F|f]ile.*[S|s]ystem.*[L|l]ockdown"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: mkdir tmp (2.2)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="mkdir.*tmp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: wget https://github.com/BoiseState/CS-HU153-resources/raw/master/activities/cs-hu153-words-dataset.tgz (2.3)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="wget.*cs-hu153-words-dataset.tgz"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: tar xzvf cs-hu153-words-dataset.tgz (2.4)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="tar.*x.*cs-hu153-words-dataset.tgz"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: ls -lR words (or) tree words (2.4)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="(ls.*l[R|r])|(tree.*words)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: sudo groupadd developers (2.5)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="sudo.*groupadd.*developers"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: sudo cat /etc/group (2.5)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="cat.*group"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity2-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: sudo chgrp -R developers words (2.6)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="sudo.*chgrp.*-R.*developers.*words"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity2-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: chmod g+rx words words/a-g words/h-m words/n-t words/u-z (2.7)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="chmod.*g\+rx"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: chmod g+r words/a-g/*.txt words/h-m/*.txt words/n-t/*.txt words/u-z/*.txt (2.7)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="chmod.*g\+r"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity2-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: ls -lR words (or) tree words (2.8)"
	local testcontentfile="module3-s2.txt"
	local expectedoutput="(ls.*l[R|r])|(tree.*words)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################


function acceptance-test-activity3-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module3-s3.txt)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="."
	local mainsrc="module3-s3.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 3 - Putting the Squeeze on Files\" (3.1)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="[S|s]cenario.*3.*-.*[P|p]utting.*[T|t]he.*[S|s]queeze.*[O|o]n.*[F|f]iles"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: cd tmp (3.2)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="cd.*tmp"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: wget https://github.com/BoiseState/CS121-public/archive/master.zip (3.3)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="wget.*master.zip"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: unzip master.zip (3.4)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="unzip.*master.zip"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: cd CS121-Public-master/examples/ (3.5)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="cd.*examples"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: du -h chap07 (3.6)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="du.*h.*chap07"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: zip -r chap07.zip chap07 (3.7)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="zip.*chap07.*chap07"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: tar czf chap07.tgz chap07 (3.8)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="(tar.*c.*chap07.tgz.*chap07)|(tar.*c.*chap07.tar.gz.*chap07)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: ls -lh chap07.zip chap07.tgz (3.9)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="ls.*l"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: scp chap07.tgz username@onyx.boisestate.edu: (3.10)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="(scp.*chap07.tgz.*onyx.*:)|(scp.*chap07.tar.gz.*onyx.*:)"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: ssh username@onyx.boisestate.edu (3.11)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="ssh.*onyx"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity3-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: tar xzf chap07.tgz (3.12)"
	local testcontentfile="module3-s3.txt"
	local expectedoutput="onyx.*tar.*x.*chap07.tgz"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################


function acceptance-test-activity4-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module3-s4.txt)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="."
	local mainsrc="module3-s4.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 4 - Room to Grow\" (4.5)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="[S|s]cenario.*4.*-.*[R|r]oom.*[T|t]o.*[G|g]row"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: df -h (4.6)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="df"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: lsblk (4.7)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="lsblk"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: sudo fdisk /dev/sdb (4.8)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="sudo.*fdisk.*dev.*sd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: lsblk (4.9)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="lsblk"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: sudo mkfs -t ext4 /dev/sdb1 (4.10)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="sudo.*mkfs.*t.*ext4.*dev.*sd"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: mkdir workspace (4.11)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="mkdir.*workspace"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity4-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: sudo mount -t ext4 /dev/sdb1 ~/workspace (4.12)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="sudo.*mount.*t.*ext4.*dev.*sd.*workspace"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: lsblk (4.13)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="lsblk"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: df -h (4.14)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="df.*h"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: ls -l (4.15)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="ls.*l"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: chown student workspace (4.16)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="chown.*workspace"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity4-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: sudo umount /dev/sdb1 (4.17)"
	local testcontentfile="module3-s4.txt"
	local expectedoutput="umount"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\LabActivity Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 30\tAcceptance Tests"
	echo -e "-t 31\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 40\tAcceptance Tests"
	echo -e "-t 41\tContent Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity1-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-13 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-14 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-15 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-16 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-17 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-18 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=18
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity2-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity2-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity2-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	


	num_tests=11
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity3-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	content-test-activity3-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity3-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity3-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=12
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity4-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity4-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity4-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity4-check-13 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=13
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


