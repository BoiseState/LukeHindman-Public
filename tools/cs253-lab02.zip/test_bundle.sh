#!/bin/bash
# Author: Luke Hindman
# Date:  Sun 24 Jan 2021 12:11:33 PM MST
# Description:  Template for developing test harness

function unit-test-template() {
	verbose=$1
	testname="Unit Test - Create/Destroy ProcEntry"
	testoutput="unit-test-create-destroy.out"
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./mytests -t 1 > ${testoutput} 2>&1

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		exit 1
	fi

}

testnum=""
verbose=0
while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 <-t test_num> [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "5" ];
then
	unit-test-template $verbose
	echo "running test $testnum"
else
	echo "unknown test $testnum"
fi




