#!/bin/bash
# Author: Luke Hindman
# Date:  Sun 24 Jan 2021 05:25:22 PM MST
# Description:  Test bundle for CS253-Lab02


###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	status=0
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Build Check"
	testoutput="quality-test-labwarmup.out"
	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testouput}.warnings
	if [ $? != 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="10\n10"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="10\n10"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-check-square() {
	verbose=$1
	status=0
	testname="Unit Test - LabWarmup - Check Square"
	testoutput="unit-test-labwarmup.out"
	testinput="10\n6"
	expectedoutput="100"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-check-cube() {
	verbose=$1
	status=0
	testname="Unit Test - LabWarmup - Check Cube"
	testoutput="unit-test-labwarmup.out"
	testinput="10\n6"
	expectedoutput="1000"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}
function unit-test-labwarmup-check-multiply() {
	verbose=$1
	status=0
	testname="Unit Test - LabWarmup - Check Multiply"
	testoutput="unit-test-labwarmup.out"
	testinput="9\n6"
	expectedoutput="54"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-check-add() {
	verbose=$1
	status=0
	testname="Unit Test - LabWarmup - Check Add"
	testoutput="unit-test-labwarmup.out"
	testinput="9\n6"
	expectedoutput="15"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabWarmup
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	status=0
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"

	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-build-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabActivity - Build Check"
	testoutput="quality-test-labactivity.out"
	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testouput}.warnings
	if [ $? != 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labactivity-run-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput=""

	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput=""

	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		status=2
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-tree-stump() {
	verbose=$1
	status=0
	testname="Unit Test - LabActivity - Check Tree Stump"
	testoutput="unit-test-labactivity.out"
	testinput=""
	expectedoutput="***"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-tree-base() {
	verbose=$1
	status=0
	testname="Unit Test - LabActivity - Check Tree Base"
	testoutput="unit-test-labactivity.out"
	testinput=""
	expectedoutput="*******"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-cat-ear() {
	verbose=$1
	status=0
	testname="Unit Test - LabActivity - Check Cat Ear"
	testoutput="unit-test-labactivity.out"
	testinput=""
	expectedoutput="/\\\\"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-cat-eyes() {
	verbose=$1
	status=0
	testname="Unit Test - LabActivity - Check Cat Eyes"
	testoutput="unit-test-labactivity.out"
	testinput=""
	expectedoutput="o o"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-check-cat-mouth() {
	verbose=$1
	status=0
	testname="Unit Test - LabActivity - Check Cat Mouth"
	testoutput="unit-test-labactivity.out"
	testinput=""
	expectedoutput="\-\-\-"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make clean > /dev/null 2>&1
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		echo "---------Test Input------------" >>${testoutput}
		echo -e "${testinput}" >>${testoutput}
		echo "---------Expected Output------------" >>${testoutput}
		echo -e "${expectedoutput}" >>${testoutput}
		echo "-------------------------------" >>${testoutput}
		./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		./myprog >> ${testoutput} 2>&1
	fi

	cat ${testoutput} |grep "${expectedoutput}" > /dev/null
	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 <-t test_num> [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "5" ];
then
	unit-test-template $verbose
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "11" ];
then
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	error_count=$(($error_count + $?))

	quality-test-labwarmup-run-check $verbose
	error_count=$(($error_count + $?))

	quality-test-labwarmup-memory-check $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "12" ];
then
	# LabWarmup Code Completeness Tests
	unit-test-labwarmup-check-square $verbose
	error_count=$(($error_count + $?))

	unit-test-labwarmup-check-cube $verbose
	error_count=$(($error_count + $?))

	unit-test-labwarmup-check-multiply $verbose
	error_count=$(($error_count + $?))

	unit-test-labwarmup-check-add $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "21" ];
then
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	error_count=$(($error_count + $?))

	quality-test-labactivity-run-check $verbose
	error_count=$(($error_count + $?))

	quality-test-labactivity-memory-check $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "22" ];
then
	# LabWarmup Code Completeness Tests
	unit-test-labactivity-check-tree-stump $verbose
	error_count=$(($error_count + $?))

	unit-test-labactivity-check-tree-base $verbose
	error_count=$(($error_count + $?))

	unit-test-labactivity-check-cat-ear $verbose
	error_count=$(($error_count + $?))

	unit-test-labactivity-check-cat-eyes $verbose
	error_count=$(($error_count + $?))

	unit-test-labactivity-check-cat-mouth $verbose
	error_count=$(($error_count + $?))
else
	echo "unknown test $testnum"
fi

exit ${error_count}


