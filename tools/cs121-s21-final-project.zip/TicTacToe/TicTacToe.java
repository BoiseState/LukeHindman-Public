import java.awt.Point;
import java.util.ArrayList;

/**
 * Interface defining the TicTacToe game model. 
 * Updated Fall2020
 * 
 * @author mvail
 * @author Luke Hindman
 */
public interface TicTacToe {
	public static enum BoardChoice {X, O, OPEN};
	public static enum GameState {X_WON, O_WON, TIE, IN_PROGRESS};
	
	/**
	 * Reset the game.
	 * All board positions are OPEN and the game is IN_PROGRESS.
	 */
	public void newGame();
	
	/**
	 * If the choice is invalid for any reason, return false.
	 * A choice is invalid if the game is over, the position is
	 * already claimed, or the player made the previous choice
	 * (no player can make two moves in a row). 
	 * If the chosen row, column position is not already claimed
	 * and the game is not already over, claim it for the player.
	 * A winning move or choosing the last open position ends
	 * the game.
	 * 
	 * @param player expecting either BoardChoice.X or BoardChoice.O
	 * @param row row to claim - value from 0 to 2
	 * @param col column to claim - value from 0 to 2
	 * @return true if the choice was a valid move, else false
	 */
	public boolean choose(BoardChoice player, int row, int col);

	/**
	 * Return true if either player X or O has achieved
	 * 3-in-a-row, whether vertically, horizontally, or diagonally,
	 * or if all positions have been claimed without a winner.
	 * 
	 * @return true if the game is over, else false
	 */
	public boolean gameOver();
	
	/**
	 * Return the winner (X, O, or TIE) if the game is over, or
	 * IN_PROGRESS if the game is not over.
	 * 
	 * @return the winner of a completed game or IN_PROGRESS
	 */
	public GameState getGameState();
	
	/**
	 * Get the current game board with each position marked as
	 * belonging to X, O, or OPEN.
	 * Preserve encapsulation by returning a copy of the original data, and
	 *    not a reference to the internal gameboard array itself.
	 * 
	 * @return array showing the current game board
	 */
	public BoardChoice[][] getGameGrid();
	
	/**
	 * Get the sequence of moves as an ArrayList of Point objects, where
	 * the first item corresponds to player 1's first move and
	 * the second item correpsonds to player 2's first move. The third 
	 * item in the list corresponds the player 1's second move
	 * and so on...
	 * 
	 * Preserve encapsulation by returning a copy of the original data, and
	 *   not a reference to the internal moves ArrayList itself.
	 *
	 * NOTE: Each move in the game is representated as a Point where the
	 * row is stored in the "x" coordinate and the column is stored in 
	 * the "y" coordinate. While possibly counter-intuitive, it is intentional.
	 * 
	 * @return ArrayList of Point objects showing the sequence of claimed positions
	 */
	public ArrayList<Point> getMoves();
	
}
