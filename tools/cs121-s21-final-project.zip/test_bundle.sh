#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 03 May 2021 08:33:24 AM MDT
# Description:  Test bundle for CS121 Final Project

source test_functions.sh

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-project-build-tictactoetester() {
	local verbose=$1
	local testname="Acceptance Test - Build (TicTacToeTester)"
	local testoutput="acceptance-test-project.out"
	local testdirectory="TicTacToe"
	local testprogram="TicTacToeTester.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-project-min-implementation-tictactoegame() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (TicTacToeGame.java)"
	local testoutput="acceptance-test-project.out"
	local testdirectory="TicTacToe"
	local mainsrc="TicTacToeGame.java"
	local minlines=15
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-project-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-project.out"
	local testdirectory="TicTacToe"
	local testprogram="none"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-project-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-project.out"
	local testdirectory="TicTacToe"
	local testprogram="none"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function unit-test-project-tictactoetester() {
	local verbose=$1
	local testname="Unit Tests - TicTacToeTester"
	local testoutput="quality-test-project.out"
	local testdirectory="TicTacToe"
	local testprogram="none"
	local result
	local exit_status

	cd ${testdirectory}
	make TicTacToeTester.class

	# Run quality test in subshell
	result=$( java TicTacToeTester )

	exit_status=$?
	echo "$result" |grep "Total Tests"
	return $exit_status
}



###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nProject Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	usage
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"
elif [ "$testnum" = "10" ]; then
	echo "Not Implemented"
	exit 1
elif [ "$testnum" = "11" ]; then
	echo "Not Implemented"
	exit 1
elif [ "$testnum" = "12" ]; then
	echo "Not Implemented"
	exit 1
elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-project-build-tictactoetester $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-project-min-implementation-tictactoegame $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-project-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	unit-test-project-tictactoetester $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1

	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}
