#!/bin/bash
# Author: Luke Hindman
# Date: Wed 07 Sep 2022 11:45:26 AM MDT
# Description:  Test bundle for CS153-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################


function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module1-s1.txt)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="module1-s1.txt"
	local minlines=5
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-1() {
	local verbose=$1
	local testname="Content Check - Expected: echo \"Scenario 1 - Basic Networking\" (4.2)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="[S|s]cenario.*1.*-.*[B|b]asic.*[N|n]etworking"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-2() {
	local verbose=$1
	local testname="Content Check - Expected: host onyx.boisestate.edu (4.3)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="host.*onyx.boisestate.edu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-3() {
	local verbose=$1
	local testname="Content Check - Expected: ping www.google.com (4.4)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="ping.*google.com"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-4() {
	local verbose=$1
	local testname="Content Check - Expected: dig www.google.com (4.5)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="dig.*google.com"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-5() {
	local verbose=$1
	local testname="Content Check - Expected: host localhost (4.6)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="host.*localhost"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-6() {
	local verbose=$1
	local testname="Content Check - Expected: firefox www.whatsmyip.org & (4.7)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="(firefox|chrome).*what[i]*smyip.org"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity1-check-7() {
	local verbose=$1
	local testname="Content Check - Expected: ssh username@onyx.boisestate.edu (4.8)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="ssh.*onyx.boisestate.edu"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-8() {
	local verbose=$1
	local testname="Content Check - Expected: who (4.9)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyx.*who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-9() {
	local verbose=$1
	local testname="Content Check - Expected: ssh onyxnode## (4.10)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyx .*ssh.*onyxnode"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-10() {
	local verbose=$1
	local testname="Content Check - Expected: who (4.10)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyxnode.*who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-11() {
	local verbose=$1
	local testname="Content Check - Expected: ssh onyxnode## (4.11)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyxnode.*ssh.*onyxnode"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-12() {
	local verbose=$1
	local testname="Content Check - Expected: who (4.11)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyxnode.*who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function content-test-activity1-check-13() {
	local verbose=$1
	local testname="Content Check - Expected: ssh onyx (4.12)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyxnode.*ssh.*onyx"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-14() {
	local verbose=$1
	local testname="Content Check - Expected: who (4.12)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="onyx.*who"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function content-test-activity1-check-15() {
	local verbose=$1
	local testname="Content Check - Expected: exit (4.13)"
	local testcontentfile="module1-s1.txt"
	local expectedoutput="exit"
	local testdirectory="."
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-check-content "$testname" "$testcontentfile" "$expectedoutput" "$testdirectory" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################


function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module1-s1.txt)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local testfile="module1-screenshot.png"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-file-exists "$testname" "$testoutput" "$testdirectory" "$testfile" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\LabActivity Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tContent Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Content Check
	content-test-activity1-check-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	content-test-activity1-check-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-10 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-11 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-12 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-13 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-14 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	content-test-activity1-check-15 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi	

	num_tests=15
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


