#!/bin/bash
# Author: Luke Hindman
# Date: Mon 19 Sep 2022 01:26:45 PM MDT
# Description:  Test bundle for CS153-Lab01

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################


function acceptance-test-activity1-min-implementation-1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Session Capture Exists (module5-s1.txt)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="module5-s1.txt"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation-2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Shell Script Exists (hello.sh)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="."
	local mainsrc="hello.sh"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-manual-test-1() {
	local verbose=$1
	local testname="Content Check - Manual Verify Script Attempt (hello.sh)"
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}



###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################


function acceptance-test-activity2-min-implementation-1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Shell Script Exists (createForest.sh)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local mainsrc="createForest.sh"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation-2() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Shell Script Exits (createDungeons.sh)"
	local testoutput="acceptance-test-activity2.out"
	local testdirectory="."
	local mainsrc="createDungeons.sh"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-manual-test-1() {
	local verbose=$1
	local testname="Content Check - Manual Verify Script Attempt (createForest.sh)"
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity2-manual-test-2() {
	local verbose=$1
	local testname="Content Check - Manual Verify Script Attempt (createDungeons.sh)"
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 3 Tests         #
#                                 #
###################################


function acceptance-test-activity3-min-implementation-1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Shell Script Exists (fileQuest.sh)"
	local testoutput="acceptance-test-activity3.out"
	local testdirectory="."
	local mainsrc="fileQuest.sh"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity3-manual-test-1() {
	local verbose=$1
	local testname="Content Check - Manual Verify Script Attempt (fileQuest.sh)"
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

###################################
#                                 #
#        Activity 4 Tests         #
#                                 #
###################################


function acceptance-test-activity4-min-implementation-1() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Shell Script Exists (test.sh)"
	local testoutput="acceptance-test-activity4.out"
	local testdirectory="."
	local mainsrc="test.sh"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity4-manual-test-1() {
	local verbose=$1
	local testname="Content Check - Manual Verify Script Attempt (test.sh)"
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\LabActivity Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 30\tAcceptance Tests"
	echo -e "-t 31\tContent Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 40\tAcceptance Tests"
	echo -e "-t 41\tContent Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity1-min-implementation-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Content Check
	integration-test-activity1-manual-test-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity2-min-implementation-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Content Check
	integration-test-activity2-manual-test-1 $verbose 
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity2-manual-test-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "30" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity3-min-implementation-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "31" ];
then
	num_passed=0
	integration-test-activity3-manual-test-1 $verbose 
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "40" ];
then
	num_passed=0
	# LabActivity Acceptance Tests

	acceptance-test-activity4-min-implementation-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "41" ];
then
	num_passed=0
	# LabActivity Content Check
	integration-test-activity4-manual-test-1 $verbose 
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


