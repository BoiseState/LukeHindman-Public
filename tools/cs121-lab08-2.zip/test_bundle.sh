#!/bin/bash
# Author: Luke Hindman
# Date: Mon 29 Nov 2021 12:44:26 PM MST
# Description:  Test bundle for CS121-Lab07

source test_functions.sh

###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity 1 (DynamicDie)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="DynamicDie"
	local testprogram="DynamicDie.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (DynamicDie.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="DynamicDie"
	local mainsrc="DynamicDie.java"
	local minlines=3
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (DynamicDie)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="DynamicDie"
	local testprogram="DynamicDie.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-manual-test-1() {
	local verbose=$1
	local testname="Integration Test - Manual Test (DieButton rolls when clicked)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-2() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Roll Die button roles die when clicked)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-3() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Reconfigure style (Diamond))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-4() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Reconfigure style (Honeycomb))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-5() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Reconfigure style (Triangle))"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-6() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Reconfigure number of sides (middle of range) )"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-7() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Reconfigure number of sides (edge cases: 2,20) )"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-8() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Check non-integer number of sides)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}

function integration-test-activity1-manual-test-9() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Check out-of-range number of sides)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="DynamicDie"
	local testprogram="java DynamicDie"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-manual-test-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-7 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-8 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-activity1-manual-test-9 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=10
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	echo "Not Implemented"
	exit 1
elif [ "$testnum" = "21" ];
then
	echo "Not Implemented"
	exit 1
elif [ "$testnum" = "22" ];
then
	echo "Not Implemented"
	exit 1
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


