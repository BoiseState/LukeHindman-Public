#!/bin/bash
# Author: Luke Hindman
# Date:  Tue 23 Feb 2021 08:07:11 AM MST
# Description:  Test bundle for CS253-Lab06

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup-build-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Build (myprog)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=20
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}



function integration-test-labwarmup-input-output() {
	local verbose=$1
	local testname="Integration Test - Input/Output (236.00 89.50 142.00 166.30 93.00)"
	local testoutput="integration-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local expectedoutput="236.00 89.50 142.00 166.30 93.00"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-total-weight() {
	local verbose=$1
	local testname="Integration Test - Total weight"
	local testoutput="integration-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local expectedoutput="726.80"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-avg-weight() {
	local verbose=$1
	local testname="Integration Test - Average weight"
	local testoutput="integration-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local expectedoutput="145.36"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-max-weight() {
	local verbose=$1
	local testname="Integration Test - Max weight"
	local testoutput="integration-test-labwarmup.out"
	local testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	local expectedoutput="236.00"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################
function acceptance-test-labactivity-build() {
	local verbose=$1
	local testname="Acceptance Test - LabActivity"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-main() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=15
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}
function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}


function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-quit1() {
	local verbose=$1
	local testname="Integration Test - Load and Quit (q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	local expectedoutput="[Q|q]uit"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-roster1() {
	local verbose=$1
	local testname="Integration Test - Load and Roster (o q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\no\nq"
	local expectedoutputfile="../sample_data/roster1.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-update1() {
	local verbose=$1
	local testname="Integration Test - Load and Update (u 23 6 o q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nu\n23\n6\no\nq"
	local expectedoutputfile="../sample_data/update1.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-filter1() {
	local verbose=$1
	local testname="Integration Test - Load and Filter (a 5 q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\na\n5\nq"
	local expectedoutputfile="../sample_data/filter1.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-replace1() {
	local verbose=$1
	local testname="Integration Test - Load and Replace (r 4 12 8 o q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nr\n4\n12\n8\no\nq"
	local expectedoutputfile="../sample_data/replace1.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-quit2() {
	local verbose=$1
	status=0
    duration=5
	local testname="Integration Test - Load and Quit (q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nq"
	local expectedoutput="[Q|q]uit"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-roster2() {
	local verbose=$1
	local testname="Integration Test - Load and Roster (o q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nq"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\no\nq"
	local expectedoutputfile="../sample_data/roster2.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-update2() {
	local verbose=$1
	local testname="Integration Test - Load and Update (u 11 2 q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nu\n11\n2\no\nq"
	local expectedoutputfile="../sample_data/update2.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-filter2() {
	local verbose=$1
	local testname="Integration Test - Load and Filter (a 4 q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\na\n4\nq"
	local expectedoutputfile="../sample_data/filter2.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-load-and-replace2() {
	local verbose=$1
	local testname="Integration Test - Load and Replace (r 2 3 8 o q)"
	local testoutput="integration-test-labactivity.out"
	local testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nr\n2\n3\n8\no\nq"
	local expectedoutputfile="../sample_data/replace2.txt"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-match-output-file "$testname" "$testoutput" "$testinput" "$expectedoutputfile" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


function integration-test-labactivity-error-handling-1() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid jersery number in data load)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\nbob\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	local expectedoutput="[Q|q]uit"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-2() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid rating number in data load)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\nbob\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	local expectedoutput="[Q|q]uit"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-3() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Invalid menu option selection)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\n!\nq"
	local expectedoutput="([E|e]rror)|([U|u]nknown option selected)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-4() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Update rating for non-existant jersey number)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nu\n111\n112\nq"
	local expectedoutput="([E|e]rror)|([N|n]on-existent jersey number selected, please check your data and try again)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-5() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Replace non-existant jersey number)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nu\n111\n85\n8\nq"
	local expectedoutput="([E|e]rror)|([N|n]on-existent jersey number selected, please check your data and try again)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-error-handling-6() {
	local verbose=$1
	local testname="Integration Test - Error Handling (Non-integer values during filter)"
	local testoutput="integration-test-labactivity.out"
	local testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\na\nbob\nq"
	local expectedoutput="([E|e]rror)|([N|n]on-integer value detected, please check your data and try again)"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

# function integration-test-labactivity-error-handling-1() {
# 	local verbose=$1
# 	local testname="Integration Test - Error Handling (Invalid Base Height)"
# 	local testoutput="integration-test-labactivity.out"
# 	local testinput="X\n2\n4"
# 	local expectedoutput="([E|e]rror)|([U|u]nrecognized input)"
# 	local testdirectory="LabActivity"
# 	local testprogram="myprog"
# 	local result
# 	local status

# 	# Run integration test in subshell
# 	result=$( test-error-handling-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
# 	status=$?
# 	echo "$result"
# 	return $status
# }


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
    duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup-build-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	integration-test-labwarmup-input-output $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-total-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-avg-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labwarmup-max-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=4
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-main $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	#echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Completeness Tests

	echo "**Team Roster Dataset 1:** 84 7 23 4 4 5 30 2 66 9"
	
	integration-test-labactivity-load-and-quit1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-roster1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-update1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-filter1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-replace1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	echo ""
	echo "**Team Roster Dataset 2:** 1 9 2 8 98 4 91 3 11 5"
	integration-test-labactivity-load-and-quit2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-roster2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-update2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-filter2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-load-and-replace2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	echo ""
	echo "**Error Handling**"
	integration-test-labactivity-error-handling-1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-4 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-5 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	integration-test-labactivity-error-handling-6 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=16
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


