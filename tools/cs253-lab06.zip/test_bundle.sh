#!/bin/bash
# Author: Luke Hindman
# Date:  Tue 23 Feb 2021 08:07:11 AM MST
# Description:  Test bundle for CS253-Lab06


###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"

	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? -eq 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Build Check"
	testoutput="quality-test-labwarmup.out"
	cd LabWarmup
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? -ne 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"


	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi

	exit_status="$?"

	if [ $exit_status == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		if [ $exit_status -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=2
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	status=0
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration  valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	elif [ $? -ne 127 ];
	then
		echo "${testname}: passed"
		status=0
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-input-output() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Input/Output (236.00 89.50 142.00 166.30 93.00)"
	testoutput="unit-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	expectedoutput="236.00 89.50 142.00 166.30 93.00"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-total-weight() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Total weight"
	testoutput="unit-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	expectedoutput="726.80"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-avg-weight() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Average weight"
	testoutput="unit-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	expectedoutput="145.36"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labwarmup-max-weight() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabWarmup - Max weight"
	testoutput="unit-test-labwarmup.out"
	testinput="236.0\n89.5\n142.0\n166.3\n93.0"
	expectedoutput="236.00"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabWarmup
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	status=0
    duration=5
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"

	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

        if [ $? == 0 ];
        then
			if [ -f myprog ];
			then
                echo "${testname}: passed"
                status=0
			else
				if [ ${verbose} -eq 1 ];
                then
                    echo "Executable Not Found: myprog"
                fi
				echo "${testname}: failed"
				status=1
			fi
        else
			if [ ${verbose} -eq 1 ];
			then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
        fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-build-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Build Check"
	testoutput="quality-test-labactivity.out"
	cd LabActivity
	make clean > /dev/null 2>&1
	make > ${testoutput} 2>&1

	cat ${testoutput} |grep -i "warning" > ${testoutput}.warnings
	if [ $? -ne 0 ];
	then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ];
		then
				cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function quality-test-labactivity-run-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration ./myprog > ${testoutput} 2>&1
	fi
	exit_status="$?"

	if [ $exit_status -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		if [ $exit_status -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=2
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	status=0
    duration=5
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog <<< "${testinput}" > ${testoutput} 2>&1
	else
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./myprog > ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	elif [ $? -ne 127 ];
	then
		echo "${testname}: passed"
		status=0
	else
		echo "${testname}: failed"
		status=2
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-quit1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Quit (q)"
	testoutput="unit-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nq"
	expectedoutput="[Q|q]uit"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-roster1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Roster (o q)"
	testoutput="unit-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\no\nq"
	expectedoutputfile="../roster1.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-update1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Update (u 23 6 o q)"
	testoutput="unit-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nu\n23\n6\no\nq"
	expectedoutputfile="../update1.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-filter1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Filter (a 5 q)"
	testoutput="unit-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\na\n5\nq"
	expectedoutputfile="../filter1.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-replace1() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Replace (r 4 12 8 o q)"
	testoutput="unit-test-labactivity.out"
	testinput="84\n7\n23\n4\n4\n5\n30\n2\n66\n9\nr\n4\n12\n8\n5\n\no\nq"
	expectedoutputfile="../replace1.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-quit2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Quit (q)"
	testoutput="unit-test-labactivity.out"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nq"
	expectedoutput="[Q|q]uit"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`

	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ];
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi
	
	if [ $? == 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else 
		cat ${testoutput} |grep -E "${expectedoutput}" > /dev/null
		if [ $? -eq 0 ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-roster2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Roster (o q)"
	testoutput="unit-test-labactivity.out"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nq"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\no\nq"
	expectedoutputfile="../roster2.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-update2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Update (u 11 2 q)"
	testoutput="unit-test-labactivity.out"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nu\n11\n2\no\nq"
	expectedoutputfile="../update2.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-filter2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Filter (a 4 q)"
	testoutput="unit-test-labactivity.out"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\na\n4\nq"
	expectedoutputfile="../filter2.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}

function unit-test-labactivity-load-and-replace2() {
	verbose=$1
	status=0
    duration=5
	testname="Unit Test - LabActivity - Load and Replace (r 2 3 8 o q)"
	testoutput="unit-test-labactivity.out"
	testinput="1\n9\n2\n8\n98\n4\n91\n3\n11\n5\nr\n2\n3\n8\no\nq"
	expectedoutputfile="../replace2.txt"

	# Evaluate escape characters in testinput
	testinput=`echo -e ${testinput}`
	
	cd LabActivity
	make > /dev/null 2>&1

	if [ -n "$testinput" ]
	then
		timeout $duration ./myprog <<<"${testinput}" >> ${testoutput} 2>&1
	else
		timeout $duration ./myprog >> ${testoutput} 2>&1
	fi

	if [ $? -eq 124 ];
	then
		echo "${testname}: timeout"
		status=1
	else
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(x in y or y in x)" "${testoutput}" "${expectedoutputfile}"`
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	cd ..
	return ${status}
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
    duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=`cat Journal.md  | grep -v "^#" | wc -w`
	if [ ${word_count} -gt 150 ];
	then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi
	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "12" ];
then
	num_passed=0
	# LabWarmup Code Completeness Tests
	unit-test-labwarmup-input-output $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-total-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-avg-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labwarmup-max-weight $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=4
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "20" ];
then
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=3
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Completeness Tests

	echo "**Team Roster Dataset 1:** 84 7 23 4 4 5 30 2 66 9"
	
	unit-test-labactivity-load-and-quit1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-roster1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-update1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-filter1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-replace1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	echo ""
	echo "**Team Roster Dataset 2:** 1 98 2 76 55 77 23 76 11 79"
	unit-test-labactivity-load-and-quit2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-roster2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-update2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-filter2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	unit-test-labactivity-load-and-replace2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi


	num_tests=10
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

elif [ "$testnum" = "30" ];
then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ];
then
	# Coding Journal Content Review
	unit-test-labactivity-check-gallons $verbose
	error_count=$(($error_count + $?))
else
	echo "unknown test $testnum"
fi

exit ${error_count}


