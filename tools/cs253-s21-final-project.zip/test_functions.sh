#!/bin/bash
# Author: Luke Hindman
# Date: Wed 10 Mar 2021 09:48:15 AM PST
# Description:  Utility functions for acceptance, quality, unit and integration testing

function test-input-output() {
	local verbose=$7
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinput="$3"
	local expectedoutput="$4"
	local testdirectory="$5"
	local testprogram="$6"
	local exit_status

	# Evaluate escape characters in testinput
	testinput=$(printf "${testinput}")

	cd "${testdirectory}"
	make >/dev/null 2>&1

	PATH=${PATH}:.
	if [ -n "$testinput" ]; then
		timeout $duration ${testprogram} <<<"${testinput}" >${testoutput} 2>&1
	else
		timeout $duration ${testprogram} >${testoutput} 2>&1
	fi

	exit_status=$?

	if [ $exit_status == 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
	else

		# Cleanup trailing whitespace characters in outputfile
		sed -i 's/ *$//g' ${testoutput}
		# Normalize Spaces
		sed -i -e 's/\s\+/ /g' ${testoutput}

		cat ${testoutput} | grep -E "${expectedoutput}" >/dev/null
		if [ $? -eq 0 ]; then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ]; then
				cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function test-input-match-output-file() {
	local verbose=$7
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinput="$3"
	local expectedoutputfile="$4"
	local testdirectory="$5"
	local testprogram="$6"
	local exit_status

	# Evaluate escape characters in testinput
	testinput=$(printf "${testinput}")
	
	cd "${testdirectory}"
	make >/dev/null 2>&1

	PATH=${PATH}:.
	if [ -n "$testinput" ]; then
		timeout $duration ${testprogram} <<<"${testinput}" >${testoutput} 2>${testoutput}.err
	else
		timeout $duration ${testprogram} >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status == 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
	else
		# Cleanup trailing whitespace characters in outputfile
		sed -i 's/ *$//g' ${testoutput}
		# Normalize Spaces
		sed -i -e 's/\s\+/ /g' ${testoutput}
		# Check to see if the contents of the expectedoutputfile is a subset of the testoutput
		result=`python3 -c "import sys; x=open(sys.argv[1]).read(); y=open(sys.argv[2]).read(); print(y in x)" "${testoutput}" "${expectedoutputfile}"`
	
		if [ "$result" == "True" ];
		then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
			status=1
		fi
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}

function test-exact-file-match-using-diff() {
	local verbose=$7
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinputfile="$3"
	local expectedoutputfile="$4"
	local testdirectory="$5"
	local testprogram="$6"
	local exit_status
	
	cd "${testdirectory}"
	make >/dev/null 2>&1

	PATH=${PATH}:.

	if [ -n "$testinputfile" ]; then
		timeout $duration cat ${testinputfile} | ${testprogram} >${testoutput} 2>${testoutput}.err
	else
		timeout $duration ${testprogram} >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status == 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
	else
		diff ${testoutput} ${expectedoutputfile} > /dev/null 2>&1
		status=$?

		if [ $status -eq 0 ];
		then
			echo "${testname}: passed"
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
		fi
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}

function test-exact-file-match-using-awk-diff() {
	local verbose=$8
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinputfile="$3"
	local expectedoutputfile="$4"
	local testdirectory="$5"
	local testprogram="$6"
	local awkfilter="$7"
	local exit_status
	
	# Setup awk filter as a pass through if no filter is specified 
	if [ "$awkfilter" == "" ];
	then
		awkfilter="{print $0}"
	fi

	cd "${testdirectory}"
	make >/dev/null 2>&1

	PATH=${PATH}:.

	if [ -n "$testinputfile" ]; then
		timeout $duration cat ${testinputfile} | ${testprogram} | eval "awk ${awkfilter}" >${testoutput} 2>${testoutput}.err
	else
		timeout $duration ${testprogram} | eval "awk ${awkfilter}" >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status == 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
	else
		diff ${testoutput} ${expectedoutputfile} > /dev/null 2>&1
		status=$?

		if [ $status -eq 0 ];
		then
			echo "${testname}: passed"
		else
			if [ ${verbose} -eq 1 ];
			then
					cat ${testoutput}
			fi
			echo "${testname}: failed"
		fi
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}


function test-memory-check() {
	local verbose="$6"
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinput="$3"
	local testdirectory="$4"
	local testprogram="$5"
	local exit_status

	# Evaluate escape characters in testinput
	testinput=$(echo -e ${testinput})

	cd "${testdirectory}"
	make >/dev/null 2>&1

	if [ -n "$testinput" ]; then
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./${testprogram} <<<"${testinput}" >${testoutput} 2>${testoutput}.err
	else
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./${testprogram} >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status -eq 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -eq 127 ]; then
		echo "${testname}: failed (memory error)"
		status=1
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}.err
		else
			echo "$( grep "ERROR SUMMARY" ${testoutput}.err )"
		fi
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}.err
		fi
	else
		echo "${testname}: passed"
		local status=
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}

function test-run-check() {
	local verbose="$6"
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinput="$3"
	local testdirectory="$4"
	local testprogram="$5"
	local exit_status

	# Evaluate escape characters in testinput
	testinput=$(echo -e ${testinput})

	cd "${testdirectory}"
	make >/dev/null 2>&1

	if [ -n "$testinput" ]; then
		timeout $duration ./${testprogram} <<<"${testinput}" >${testoutput} 2>${testoutput}.err
	else
		timeout $duration ./${testprogram} >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status == 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	else
		if [ $exit_status -eq 0 ]; then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ]; then
				cat ${testoutput}.err
			fi
			echo "${testname}: failed"
			status=2
		fi
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}

function test-clean-build-check() {
	local verbose=$5
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testdirectory="$3"
	local testprogram="$4"
	local exit_status

	cd "${testdirectory}"
	make clean >/dev/null 2>&1
	make >${testoutput} 2>&1

	cat ${testoutput} | grep -i "warning" >${testoutput}.warnings
	if [ $? -ne 0 ]; then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}.warnings
		fi
		echo "${testname}: failed"
		status=1
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.warnings
	cd ..
	return ${status}
}

function test-build-check() {
	local verbose=$5
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testdirectory="$3"
	local testprogram="$4"
	local exit_status

	cd "${testdirectory}"

	make clean >/dev/null 2>&1
	make ${testprogram} >${testoutput} 2>&1

	if [ $? == 0 ]; then
		if [ -f "${testprogram}" ]; then
			echo "${testname}: passed"
			status=0
		else
			if [ ${verbose} -eq 1 ]; then
				echo "Executable Not Found: ${testprogram}"
			fi
			echo "${testname}: failed"
			status=1
		fi
	else
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function test-min-lines-check() {

	local testname="$1"
	local testoutput="$2"
	local testdirectory="$3"
	local main_src="$4"
	local min_lines="$5"
	local verbose="$6"
	local status=0
	local num_lines

	cd "${testdirectory}"

	# Count the number of non-blank lines
	num_lines=$(cat ${main_src} 2>${testoutput}| sed '/^[[:space:]]*$/d' | wc -l)

	if [ ${num_lines} -ge ${min_lines} ]; then
		echo "${testname}: passed"
		status=0
	else
		if [ ${verbose} -eq 1 ]; then
			echo "Found ${num_lines} lines but was expecting a minimum of ${min_lines} lines in ${main_src}..."
			cat ${testoutput}
		fi
		echo "${testname}: failed"
		status=1
	fi
	rm -f ${testoutput}
	cd ..
	return ${status}
}

function test-run-unit-test() {
	local verbose="$6"
	local status=0
	local duration=5
	local testname="$1"
	local testoutput="$2"
	local testinput="$3"
	local testdirectory="$4"
	local testprogram="$5"
	local exit_status

	# Evaluate escape characters in testinput
	testinput=$(echo -e ${testinput})

	cd "${testdirectory}"
	make mytests >${testoutput} 2>&1

	exit_status=$?
	# Confirm build completed successfully
	if [ $exit_status == 0 ]; then
		if [ ! -f "mytests" ]; then
			if [ ${verbose} -eq 1 ]; then
				cat ${testoutput}
			fi
			echo "${testname}: failed (mytests did not compile)"
			status=1
		fi
	else
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}
		fi
		echo "${testname}: failed (mytests did not compile)"
		status=1
	fi

	# Fail Fast if unit tests did not build correctly
	if [ $status -ne 0 ]; then
		rm -f ${testoutput}
		cd ..
		return ${status}
	fi

	# Run Unit Test
	if [ -n "$testinput" ]; then
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./${testprogram} <<<"${testinput}" >${testoutput} 2>${testoutput}.err
	else
		timeout $duration valgrind --error-exitcode=127 --tool=memcheck --leak-check=yes --show-reachable=yes ./${testprogram} >${testoutput} 2>${testoutput}.err
	fi

	exit_status=$?

	if [ $exit_status -eq 124 ]; then
		echo "${testname}: failed (timeout)"
		status=1
	elif [ $exit_status -eq 127 ]; then
		echo "${testname}: failed (memory error)"
		status=1
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}.err
		else
			echo "$( grep "ERROR SUMMARY" ${testoutput}.err )"
		fi
	elif [ $exit_status -ne 0 ]; then
		echo "${testname}: failed (nonzero exit status)"
		status=1
		if [ ${verbose} -eq 1 ]; then
			cat ${testoutput}.err
		fi
	else
		echo "${testname}: passed"
		status=0
	fi

	rm -f ${testoutput}
	rm -f ${testoutput}.err
	cd ..
	return ${status}
}
