/* 
 * File: mytests.c
 * Author: Luke Hindman
 * Date: Wed 28 Apr 2021 03:25:55 PM MDT
 * Description: Unit tests for ProcEntry component of the Final Project
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>

#include "ProcEntry.h"

#define UNUSED(x) (void)(x)
#define DISP_MSG(MSG)                                \
   if (write(STDOUT_FILENO, MSG, strlen(MSG)) == -1) \
      perror("write");

/* Define error handler */
static void handler(int sig, siginfo_t *si, void *unused)
{
   UNUSED(sig);
   UNUSED(unused);
   if (si->si_signo == SIGSEGV)
   {
      DISP_MSG("failed (segfault)\n")
      exit(1);
   }
}

int testCreateDestroy(void)
{
   char testName[] = "Unit Test - Create/Destroy ProcEntry:";
   ProcEntry *testNode = CreateProcEntry();
   if (testNode == NULL)
   {
      fprintf(stderr, "%s failed\n", testName);
      return 1;
   }
   DestroyProcEntry(testNode);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileDestroy(void) {
   char testName[] = "Unit Test - CreateFromFile/Destroy ProcEntry";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/onyx_proc/9906/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   } 
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFilePrint1(void) {
   char testName[] = "Unit Test - PrintProcEntry (onyx_proc/9906/stat)";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/onyx_proc/9906/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s check output\n", testName);
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   return 0;
}

int testCreateFromFilePrint2(void) {
   char testName[] = "Unit Test - PrintProcEntry (onyx_proc/19070/stat)";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/onyx_proc/19070/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s check output\n", testName);
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   
   return 0;
}

int testCreateFromFilePrint3(void) {
   char testName[] = "Unit Test - PrintProcEntry (onyx_proc/593/stat)";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/onyx_proc/593/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s check output\n", testName);
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   
   return 0;
}
int testCreateFromFilePrint4(void) {
   char testName[] = "Unit Test - PrintProcEntry (onyx_proc/1/stat)";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/onyx_proc/1/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s check output\n", testName);
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   
   return 0;
}

int testCreateFromFilePrint5(void) {
   char testName[] = "Unit Test - PrintProcEntry (budgie_proc/55986/stat)";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/budgie_proc/55986/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s check output\n", testName);
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   
   return 0;
}

int testCreateFromFileNULL(void) {
   char testName[] = "Unit Test - CreateFromFile NULL Test";
   ProcEntry * testEntry = CreateProcEntryFromFile(NULL);
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileDoesNotExist(void) {
   char testName[] = "Unit Test - CreateFromFile DoesNotExist Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("does_not_exist.txt");
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileInvalidFormat(void) {
   char testName[] = "Unit Test - CreateFromFile InvalidFormat Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("mytests.c");
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}


int testECSingleSpace(void) {
   char testName[] = "Extra Credit - Single Space Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.single_space");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECTwoSpaces(void) {
   char testName[] = "Extra Credit - Two Spaces Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.two_spaces");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECManySpaces(void) {
   char testName[] = "Extra Credit - Many Spaces Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.many_spaces");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECSingleOpeningParan(void) {
   char testName[] = "Extra Credit - Single Opening Paran Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.single_opening_paran");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECSingleClosingParan(void) {
   char testName[] = "Extra Credit - Single Closing Paran Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.single_closing_paran");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECNestedParans(void) {
   char testName[] = "Extra Credit - Nested Parans Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.nested_parans");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}

int testECSurroundedWords(void) {
   char testName[] = "Extra Credit - Surrounded Words Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("../sample_data/test_data_ec/stat.surrounded_words");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s: passed\n", testName);
   return 0;
}



int runall(void)
{

   int status = 0;
   printf("Running Unit Tests:\n");
   status += testCreateDestroy();
   status += testCreateFromFileDestroy();
   status += testCreateFromFileNULL();
   status += testCreateFromFileDoesNotExist();
   status += testCreateFromFileInvalidFormat();
   status += testCreateFromFilePrint1();
   status += testCreateFromFilePrint2();
   status += testCreateFromFilePrint3();
   status += testCreateFromFilePrint4();
   status += testCreateFromFilePrint5();
   printf("Checking Extra Credit:\n");
   testECSingleSpace();
   testECTwoSpaces();
   testECManySpaces();
   testECSingleOpeningParan();
   testECSingleClosingParan();
   testECNestedParans();
   testECSurroundedWords();

   return status;
}

void setup_signal_handling(void)
{
   /* Setup signal handling to catch segfault */
   struct sigaction sa;
   sa.sa_flags = SA_SIGINFO;
   sigemptyset(&sa.sa_mask);
   sa.sa_sigaction = handler;
   if (sigaction(SIGSEGV, &sa, NULL) == -1)
      perror("sigaction");
}

int main(int argc, char *argv[])
{
   int status = 0;

   if (argc == 1)
   {
      status = runall();
   }
   else if (argc == 3)
   {
      int test_num = atoi(argv[2]);

      setup_signal_handling();

      switch (test_num)
      {
      case 1:
         /* Safe Path */
         status = testCreateDestroy();
         break;
      case 2:
         /* Safe Path */
         status = testCreateFromFileDestroy();
         break;
      case 3:
         /* Invalid Path */
         status = testCreateFromFileNULL();
         break;
      case 4:
         /* Invalid Path */
         status = testCreateFromFileDoesNotExist();
         break;
      case 5:
         /* Invalid Path*/
         status = testCreateFromFileInvalidFormat();
         break;
      case 6:
         /* Safe Path */
         status = testCreateFromFilePrint1();
         break;  
      case 7:
         /* Safe Path */
         status = testCreateFromFilePrint2();
         break; 
      case 8:
         /* Safe Path */
         status = testCreateFromFilePrint3();
         break; 
      case 9:
         /* Safe Path */
         status = testCreateFromFilePrint4();
         break;                                   
      case 10:
         /* Safe Path */
         status = testCreateFromFilePrint5();
         break;          
      case 30:
         /* Extra Credit */
         status = testECSingleSpace();
         break;
      case 31:
         /* Extra Credit */
         status += testECTwoSpaces();
         break;
      case 32:
         /* Extra Credit */
         status += testECManySpaces();
         break;
      case 33:
         /* Extra Credit */
         status += testECSingleOpeningParan();
         break;
      case 34:
         /* Extra Credit */
         status += testECSingleClosingParan();
         break;
      case 35:
         /* Extra Credit */
         status += testECNestedParans();
         break;
      case 36:
         /* Extra Credit */
         status += testECSurroundedWords();
         break;
      default:
         /* Unknown test selection */
         printf("Invalid test specified\n");
         printf("usage: %s [-t <test num>]\n", argv[0]);
         exit(1);
         break;
      }
   } 
   else
   {
      printf("usage: %s [-t <test num>]\n", argv[0]);
      exit(1);
   }
   

   return status;
}

