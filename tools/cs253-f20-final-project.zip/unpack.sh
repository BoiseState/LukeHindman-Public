#!/bin/bash

# Unpack test data
rm -Rf test_data
rm -Rf test_data_ec

tar -xzf test_data.tgz
tar -xzf test_data_ec.tgz

