#!/bin/bash


function myps-pid_sort() {
	testname="Test myps - pid sort"
	./myps -d test_data/onyx_proc -p > myps-pid_sort.out
	diff -w -i -a myps-pid_sort.out test_data/onyx_proc_expected/myps-pid_sort.out

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		echo "${testname}: failed"
		exit 1
	fi
}

function myps-cmd_sort() {
	testname="Test myps - cmd sort"
	./myps -d test_data/onyx_proc -c | awk '{print $6}'> myps-cmd_sort-stripped.out
	cat test_data/onyx_proc_expected/myps-cmd_sort.out | awk '{print $6}'> test_data/onyx_proc_expected/myps-cmd_sort-stripped.out
	diff -w -i -a myps-cmd_sort-stripped.out test_data/onyx_proc_expected/myps-cmd_sort-stripped.out

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		echo "${testname}: failed"
		exit 1
	fi
}

function myps-zombie_only {	
	testname="Test myps - zombie only"
	./myps -d test_data/onyx_proc -z > myps-zombie_only.out
	diff -w -i -a myps-zombie_only.out test_data/onyx_proc_expected/myps-zombie_only.out

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		echo "${testname}: failed"
		exit 1
	fi
}


testnum=""
while getopts t: flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 <-t test_num>"
	exit 1
fi

# Unpack test data
rm -Rf test_data
rm -Rf test_data_ec

tar -xzf test_data.tgz
tar -xzf test_data_ec.tgz

if [ "$testnum" = "1" ];
then
	myps-pid_sort
elif [ "$testnum" = "2" ];
then
	myps-cmd_sort
elif [ "$testnum" = "3" ];
then
	myps-zombie_only
fi




