#!/bin/bash


function myps-pid_sort() {
	verbose=$1
	testname="Test myps - pid sort"
	testoutput="myps-pid_sort.out"
	./myps -d test_data/onyx_proc -p > ${testoutput}
	diff -w -i -a myps-pid_sort.out test_data/onyx_proc_expected/${testoutput} > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi

}

function myps-cmd_sort() {
	verbose=$1
	testname="Test myps - cmd sort"
	testoutput="myps-cmd_sort.out"
	./myps -d test_data/onyx_proc -c | awk '{print $6}'> ${testoutput}.stripped
	cat test_data/onyx_proc_expected/${testoutput} | awk '{print $6}'> test_data/onyx_proc_expected/${testoutput}.stripped
	diff -w -i -a ${testoutput}.stripped test_data/onyx_proc_expected/${testoutput}.stripped > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi

}


function myps-zombie_only {	
	verbose=$1
	testname="Test myps - zombie only"
	testoutput="myps-zombie_only.out"
	./myps -d test_data/onyx_proc -p > ${testoutput}
	diff -w -i -a myps-pid_sort.out test_data/onyx_proc_expected/${testoutput} > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi
}


testnum=""
verbose=0
while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 <-t test_num> [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	myps-pid_sort $verbose
elif [ "$testnum" = "2" ];
then
	myps-cmd_sort $verbose
elif [ "$testnum" = "3" ];
then
	myps-zombie_only $verbose
fi




