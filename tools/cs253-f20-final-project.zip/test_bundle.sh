#!/bin/bash

function unit-test-create-destroy() {
	verbose=$1
	testname="Unit Test - Create/Destroy ProcEntry"
	testoutput="unit-test-create-destroy.out"
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./mytests -t 1 > ${testoutput} 2>&1

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		exit 1
	fi

}
function unit-test-create-from-file-destroy() {
	verbose=$1
	testname="Unit Test - CreateFromFile/Destroy ProcEntry"
	testoutput="unit-test-create-from-file-destroy.out"
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./mytests -t 2 > ${testoutput} 2>&1

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		exit 1
	fi

}
function unit-test-create-from-file-print-destroy() {
	verbose=$1
	testname="Unit Test - CreateFromFile/Print/Destroy ProcEntry"
	testoutput="unit-test-create-from-file-print-destroy.out"
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./mytests -t 3 > ${testoutput} 2>&1

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | grep "ERROR SUMMARY"
		fi
		echo "${testname}: failed"
		exit 1
	fi

}

function myps-valgrind() {
	verbose=$1
	testname="Test myps - valgrind"
	testoutput="myps-valgrind.out"
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes ./myps -d test_data/onyx_proc > /dev/null 2> ${testoutput}

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}
		else
			cat ${testoutput} | tail -1
		fi
		echo "${testname}: failed"
		exit 1
	fi

}

function myps-pid_sort() {
	verbose=$1
	testname="Test myps - pid sort"
	testoutput="myps-pid_sort.out"
	./myps -d test_data/onyx_proc -p > ${testoutput}
	diff -w -i -a ${testoutput} test_data/onyx_proc_expected/${testoutput} > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi

}

function myps-cmd_sort() {
	verbose=$1
	testname="Test myps - cmd sort"
	testoutput="myps-cmd_sort.out"
	./myps -d test_data/onyx_proc -c | awk '{print $6}'> ${testoutput}.stripped
	cat test_data/onyx_proc_expected/${testoutput} | awk '{print $6}'> test_data/onyx_proc_expected/${testoutput}.stripped
	diff -w -i -a ${testoutput}.stripped test_data/onyx_proc_expected/${testoutput}.stripped > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi

}


function myps-zombie_only {	
	verbose=$1
	testname="Test myps - zombie only"
	testoutput="myps-zombie_only.out"
	./myps -d test_data/onyx_proc -z > ${testoutput}
	diff -w -i -a ${testoutput} test_data/onyx_proc_expected/${testoutput} > ${testoutput}.diff

	if [ $? == 0 ];
	then
		echo "${testname}: passed"
		exit 0
	else
		diff_count=`cat ${testoutput}.diff | grep "^[<|>]" | wc -l`
		if [ ${verbose} -eq 1 ];
		then
			cat ${testoutput}.diff
		fi
		echo "${testname}: failed ($diff_count differences found)"
		exit 1
	fi
}


testnum=""
verbose=0
while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	echo "Usage: $0 <-t test_num> [-v]"
	exit 1
fi

if [ "$testnum" = "1" ];
then
	myps-pid_sort $verbose
elif [ "$testnum" = "2" ];
then
	myps-cmd_sort $verbose
elif [ "$testnum" = "3" ];
then
	myps-zombie_only $verbose
elif [ "$testnum" = "4" ];
then
	myps-valgrind $verbose
elif [ "$testnum" = "5" ];
then
	unit-test-create-destroy $verbose
elif [ "$testnum" = "6" ];
then
	unit-test-create-from-file-destroy $verbose
elif [ "$testnum" = "7" ];
then
	unit-test-create-from-file-print-destroy $verbose
fi




