#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "ProcEntry.h"

int testCreateDestroy(void) {
   char testName[] = "Create/Destroy Test";
   ProcEntry * testEntry = CreateProcEntry();
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   } 
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileDestroy(void) {
   char testName[] = "CreateFromFile/Destroy Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data/test_proc/999/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   } 
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFilePrintDestroy(void) {
   char testName[] = "CreateFromFile/Print/Destroy Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data/test_proc/999/stat");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stdout,"\t");
   PrintProcEntry(testEntry);
   DestroyProcEntry(testEntry);
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileNULL(void) {
   char testName[] = "CreateFromFile NULL Test";
   ProcEntry * testEntry = CreateProcEntryFromFile(NULL);
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}

int testCreateFromFileDoesNotExist(void) {
   char testName[] = "CreateFromFile DoesNotExist Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("does_not_exist.txt");
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}


int testCreateFromFileInvalidFormat(void) {
   char testName[] = "CreateFromFile InvalidFormat Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("mytests.c");
   if (testEntry != NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s passed\n", testName);
   return 0;
}


int testECSingleSpace(void) {
   char testName[] = "Extra Credit Single Space Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.single_space");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 (hello world)             test_data_ec/stat.single_space\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECTwoSpaces(void) {
   char testName[] = "Extra Credit Two Spaces Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.two_spaces");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 (hello beautiful world)   test_data_ec/stat.two_spaces\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECManySpaces(void) {
   char testName[] = "Extra Credit Many Spaces Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.many_spaces");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 (h e l l o w o r l d)     test_data_ec/stat.many_spaces\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECSingleOpeningParan(void) {
   char testName[] = "Extra Credit Single Opening Paran Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.single_opening_paran");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 (hello(world)             test_data_ec/stat.single_opening_paran\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECSingleClosingParan(void) {
   char testName[] = "Extra Credit Single Closing Paran Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.single_closing_paran");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 (hello)world)             test_data_ec/stat.single_closing_paran\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECNestedParans(void) {
   char testName[] = "Extra Credit Nested Parans Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.nested_parans");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 ((hello world))           test_data_ec/stat.nested_parans\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int testECSurroundedWords(void) {
   char testName[] = "Extra Credit Surrounded Words Test";
   ProcEntry * testEntry = CreateProcEntryFromFile("test_data_ec/stat.surrounded_words");
   if (testEntry == NULL) {
      fprintf(stderr,"%s failed\n", testName);
      return 1;
   }
   fprintf(stderr, "%s: started\n", testName);
   fprintf(stdout,"\t- Generated Output: ");
   PrintProcEntry(testEntry);
   fprintf(stdout,"\t-  Expected Output:    1080     S     0     0    1 ((hello) (world))         test_data_ec/stat.surrounded_words\n");
   DestroyProcEntry(testEntry);
   fprintf(stdout, "%s: passed\n", testName);
   return 0;
}

int runAll(void) {
   int status = 0;
   status += testCreateDestroy();
   status += testCreateFromFileDestroy();
   status += testCreateFromFilePrintDestroy();
   status += testCreateFromFileNULL();
   status += testCreateFromFileDoesNotExist();
   status += testCreateFromFileInvalidFormat();
   status += testECSingleSpace();
   status += testECTwoSpaces();
   status += testECManySpaces();
   status += testECSingleOpeningParan();
   status += testECSingleClosingParan();
   status += testECNestedParans();
   status += testECSurroundedWords();

   return status;
}

int main (int argc, char * argv[]) {

   int opt;
   int testNum = 0;
   int status = 0;

   /* Process commandline arguments with getopt() */
    while ( (opt = getopt(argc, argv, "t:h")) != -1 ) {
        switch (opt) {
            case 'h':
                fprintf(stderr,"Usage: %s <-t test_num >  [-h]\n", argv[0]);
                exit(0);
                break;
            case 't':
                testNum = atoi(optarg);
                break;
            default:
                fprintf(stderr,"Usage: %s <-t test_num >  [-h]\n", argv[0]);
                exit(1);
                break;
        }
    }

    switch (testNum) {
        case 0:
            status = runAll();
            break;
        case 1:
            status = testCreateDestroy();
            break;
        case 2:
            status = testCreateFromFileDestroy();
            break;
        case 3: 
            status = testCreateFromFilePrintDestroy();
            break;
        case 4:
            status = testCreateFromFileNULL();
            break;
        case 5:
            status = testCreateFromFileDoesNotExist();
            break;
        case 6:
            status = testCreateFromFileInvalidFormat();
            break;
        case 7:
            status = testECSingleSpace();
            break;
        case 8:
            status = testECTwoSpaces();
            break;
        case 9:
            status = testECManySpaces();
            break;
        case 10:
            status = testECSingleOpeningParan();
            break;
        case 11:
            status = testECSingleClosingParan();
            break;
        case 12:
            status = testECNestedParans();
            break;
        case 13:
            status = testECSurroundedWords();
            break;
        default:
            fprintf(stderr,"Unknown test number: %d\n", testNum);
            exit(1);
            break;

    }

   return status;
}
