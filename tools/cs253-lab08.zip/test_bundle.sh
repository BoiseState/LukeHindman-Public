#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 01 Mar 2021 07:25:51 AM MST
# Description:  Test bundle for CS253-Lab07

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup() {
	verbose=$1
	testname="Acceptance Test - LabWarmup"
	testoutput="acceptance-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-build-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Clean Build Check"
	testoutput="quality-test-labwarmup.out"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-run-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Run Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	testdirectory="LabWarmup"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labwarmup-memory-check() {
	verbose=$1
	testname="Quality Test - LabWarmup - Memory Check"
	testoutput="quality-test-labwarmup.out"
	testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-item1-check() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check Item1"
	testoutput="integration-test-labwarmup.out"
	testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	expectedoutput="Chocolate Chips 1 @ [\\\$]?3 = [\\\$]?3"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-item2-check() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check Item2"
	testoutput="integration-test-labwarmup.out"
	testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	expectedoutput="Bottled Water 10 @ [\\\$]?1 = [\\\$]?10"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-total-check() {
	verbose=$1
	testname="Integration Test - LabWarmup - Check Total"
	testoutput="integration-test-labwarmup.out"
	testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	expectedoutput="[\\\$]?13"
	testdirectory="LabWarmup"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity() {
	verbose=$1
	testname="Acceptance Test - LabActivity"
	testoutput="acceptance-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-build-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Clean Build Check"
	testoutput="quality-test-labactivity.out"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}


function quality-test-labactivity-run-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Run Check"
	testoutput="quality-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"

	return $?
}

function quality-test-labactivity-memory-check() {
	verbose=$1
	testname="Quality Test - LabActivity - Memory Check"
	testoutput="quality-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run quality test
	test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-name() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Name"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	expectedoutput="John Doe"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-date() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Date"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	expectedoutput="February 1, 2016"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-single-and-output() {
	verbose=$1
	testname="Integration Test - LabActivity - Check Add Item and Output (single item)"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	expectedoutput="Nike Romaleos 2 @ [\\\$]?189 = [\\\$]?378"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-output1() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Output Item 1"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats\nBluetooth headphones\n128\n1\no\nq"
	expectedoutput="Nike Romaleos 2 @ [\\\$]?189 = [\\\$]?378"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-output2() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Output Item 2"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	expectedoutput="Chocolate Chips 5 @ [\\\$]?3 = [\\\$]?15"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-output3() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Output Item 3"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	expectedoutput="Powerbeats Headphones 1 @ [\\\$]?128 = [\\\$]?128"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-total() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Total "
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	expectedoutput="[\\\$]?521"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-description1() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Describe Item 1"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	expectedoutput="Nike Romaleos.[ ]+Volt color, Weightlifting shoes"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-description2() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Describe Item 2"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	expectedoutput="Chocolate Chips.[ ]+Semi-sweet"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-and-description3() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Describe Item 2"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	expectedoutput="Powerbeats Headphones.[ ]+Bluetooth headphones"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-change-and-output1() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Change Item 1"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nNike Romaleos\n3\no\nq"
	expectedoutput="Nike Romaleos 3 @ [\\\$]?189 = [\\\$]?567"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-change-and-output2() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Change Item 2"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nChocolate Chips\n17\no\nq"
	expectedoutput="Chocolate Chips 17 @ [\\\$]?3 = [\\\$]?51"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-change-and-output3() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Change Item 3"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nPowerbeats Headphones\n2\no\nq"
	expectedoutput="Powerbeats Headphones 2 @ [\\\$]?128 = [\\\$]?256"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-remove-and-output1() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Remove Item 1"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nNike Romaleos\no\nq"
	expectedoutput="143"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-remove-and-output2() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Remove Item 2"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nChocolate Chips\no\nq"
	expectedoutput="506"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-remove-and-output3() {
	verbose=$1
	testname="Integration Test - LabActivity - Add Three and Remove Item 3"
	testoutput="integration-test-labactivity.out"
	testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nPowerbeats Headphones\no\nq"
	expectedoutput="393"
	testdirectory="LabActivity"
	testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	verbose=$1
	status=0
	duration=5
	testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	echo "Usage: $0 -t test_num [-v]"
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"
elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	integration-test-labwarmup-item1-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-item2-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-total-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	integration-test-labactivity-check-name $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-date $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-single-and-output $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-total $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-change-and-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-change-and-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-change-and-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=16
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))
elif [ "$testnum" = "50" ]; then
	num_passed=0

	# One-off testing
	num_tests=1
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

else
	echo "unknown test $testnum"
fi

exit ${error_count}
