#!/bin/bash
# Author: Luke Hindman
# Date:  Mon 01 Mar 2021 07:25:51 AM MST
# Description:  Test bundle for CS253-Lab08

source test_functions.sh

###################################
#                                 #
#        Lab Warmup Tests         #
#                                 #
###################################

function acceptance-test-labwarmup-build-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Build (myprog)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labwarmup-min-implementation-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local mainsrc="main.c"
	local minlines=20
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labwarmup.out"
	local testdirectory="LabWarmup"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=0
	echo "${testname}: skipped"
	return $exit_status
}

function quality-test-labwarmup-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	local testdirectory="LabWarmup"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labwarmup-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labwarmup.out"
	local testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	local testdirectory="LabWarmup"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-item1-check() {
	local verbose=$1
	local testname="Integration Test - Check Item1"
	local testoutput="integration-test-labwarmup.out"
	local testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	local expectedoutput="Chocolate Chips.*1.*3.*3"
	local testdirectory="LabWarmup"
	local testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labwarmup-item2-check() {
	local verbose=$1
	local testname="Integration Test - Check Item2"
	local testoutput="integration-test-labwarmup.out"
	local testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	local expectedoutput="Bottled Water.*10.*1.*10"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labwarmup-total-check() {
	local verbose=$1
	local testname="Integration Test - Check Total"
	local testoutput="integration-test-labwarmup.out"
	local testinput="Chocolate Chips\n3\n1\nBottled Water\n1\n10"
	local expectedoutput="[\\\$]?13"
	local testdirectory="LabWarmup"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

###################################
#                                 #
#        Lab Activity Tests       #
#                                 #
###################################

function acceptance-test-labactivity-build-myprog() {
	local verbose=$1
	local testname="Acceptance Test - LabActivity"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-labactivity-min-implementation-myprog() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (main.c)"
	local testoutput="acceptance-test-labactivity.out"
	local testdirectory="LabActivity"
	local mainsrc="main.c"
	local minlines=15
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check"
	local testoutput="quality-test-labactivity.out"
	local testdirectory="LabActivity"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=0
	echo "${testname}: skipped"
	return $exit_status
}


function quality-test-labactivity-run-check() {
	local verbose=$1
	local testname="Quality Test - Run Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	local testdirectory="LabActivity"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-run-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-labactivity-memory-check() {
	local verbose=$1
	local testname="Quality Test - Memory Check"
	local testoutput="quality-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	local testdirectory="LabActivity"
	local testprogram="myprog"

	# Run quality test in subshell
	result=$( test-memory-check "$testname" "$testoutput" "$testinput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-name() {
	local verbose=$1
	local testname="Integration Test - Check Name"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	local expectedoutput="John Doe"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-date() {
	local verbose=$1
	local testname="Integration Test - Check Date"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	local expectedoutput="February 1, 2016"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-single-and-output() {
	local verbose=$1
	local testname="Integration Test - Check Add Item and Output (single item)"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\no\nq"
	local expectedoutput="Nike Romaleos.*2.*189.*378"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-output1() {
	local verbose=$1
	local testname="Integration Test - Add Three and Output Item 1"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats\nBluetooth headphones\n128\n1\no\nq"
	local expectedoutput="Nike Romaleos.*2.*189.*378"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-output2() {
	local verbose=$1
	local testname="Integration Test - Add Three and Output Item 2"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	local expectedoutput="Chocolate Chips.*5.*3.*15"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-output3() {
	local verbose=$1
	local testname="Integration Test - Add Three and Output Item 3"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	local expectedoutput="Powerbeats Headphones.*1.*128.*128"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-total() {
	local verbose=$1
	local testname="Integration Test - Add Three and Total "
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\no\nq"
	local expectedoutput="[\\\$]?521"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-description1() {
	local verbose=$1
	local testname="Integration Test - Add Three and Describe Item 1"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	local expectedoutput="Nike Romaleos.*Volt color, Weightlifting shoes"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-description2() {
	local verbose=$1
	local testname="Integration Test - Add Three and Describe Item 2"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	local expectedoutput="Chocolate Chips.*Semi-sweet"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-and-description3() {
	local verbose=$1
	local testname="Integration Test - Add Three and Describe Item 3"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\ni\nq"
	local expectedoutput="Powerbeats Headphones.*Bluetooth headphones"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-change-and-output1() {
	local verbose=$1
	local testname="Integration Test - Add Three and Change Item 1"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nNike Romaleos\n3\no\nq"
	local expectedoutput="710"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-change-and-output2() {
	local verbose=$1
	local testname="Integration Test - Add Three and Change Item 2"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nChocolate Chips\n17\no\nq"
	local expectedoutput="557"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-change-and-output3() {
	local verbose=$1
	local testname="Integration Test - Add Three and Change Item 3"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nc\nPowerbeats Headphones\n2\no\nq"
	local expectedoutput="649"
	local testdirectory="LabActivity"
	local testprogram="myprog"

	# Run integration test
	test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose"
	return $?
}

function integration-test-labactivity-check-add-three-remove-and-output1() {
	local verbose=$1
	local testname="Integration Test - Add Three and Remove Item 1"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nNike Romaleos\no\nq"
	local expectedoutput="143"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-remove-and-output2() {
	local verbose=$1
	local testname="Integration Test - Add Three and Remove Item 2"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nChocolate Chips\no\nq"
	local expectedoutput="506"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-labactivity-check-add-three-remove-and-output3() {
	local verbose=$1
	local testname="Integration Test - Add Three and Remove Item 3"
	local testoutput="integration-test-labactivity.out"
	local testinput="John Doe\nFebruary 1, 2016\na\nNike Romaleos\nVolt color, Weightlifting shoes\n189\n2\na\nChocolate Chips\nSemi-sweet\n3\n5\na\nPowerbeats Headphones\nBluetooth headphones\n128\n1\nr\nPowerbeats Headphones\no\nq"
	local expectedoutput="393"
	local testdirectory="LabActivity"
	local testprogram="myprog"
	local result
	local exit_status

	# Run integration test in subshell
	result=$( test-input-output "$testname" "$testoutput" "$testinput" "$expectedoutput" "$testdirectory" "$testprogram" "$verbose" )
	exit_status=$?
	echo "$result"
	return $exit_status
}


###################################
#                                 #
#      Coding Journal Check       #
#                                 #
###################################

function coding-journal-content-review() {
	local verbose=$1
	status=0
	duration=5
	local testname="Coding Journal - Content Review"

	cd CodingJournal

	word_count=$(cat Journal.md | grep -v "^#" | wc -w)
	if [ ${word_count} -gt 150 ]; then
		echo "${testname}: criteria satisfied"
		status=0
	else
		echo "${testname}: criteria not satisfied"
		status=1
	fi

	cd ..
	return ${status}
}

###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
	echo -e "\nCodeJournal Test Options:"
	echo -e "-t 30\tAcceptance Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag; do
	case "${flag}" in
	t) testnum=${OPTARG} ;;
	v) verbose=1 ;;
	esac
done

if [ "$testnum" = "" ]; then
	usage
	exit 1
fi

if [ "$testnum" = "1" ]; then
	echo "running test $testnum"
elif [ "$testnum" = "10" ]; then
	num_passed=0
	# LabWarmup Acceptance Tests
	acceptance-test-labwarmup-build-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labwarmup-min-implementation-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "11" ]; then
	num_passed=0
	# LabWarmup Code Quality Tests
	quality-test-labwarmup-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labwarmup-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "12" ]; then
	num_passed=0
	# LabWarmup Code Completeness Tests

	integration-test-labwarmup-item1-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-item2-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labwarmup-total-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "20" ]; then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-labactivity-build-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-labactivity-min-implementation-myprog $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	# echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "21" ]; then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-labactivity-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-run-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	quality-test-labactivity-memory-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=3
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "22" ]; then
	num_passed=0
	# LabActivity Code Completeness Tests

	integration-test-labactivity-check-name $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-date $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-single-and-output $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-total $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-and-description3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output1 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output2 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	integration-test-labactivity-check-add-three-remove-and-output3 $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=13
	score=$(bc <<<"scale=3; 100.0 * $num_passed/$num_tests")
	echo "Score: $score%"
	error_count=$(expr $num_tests - $num_passed)

elif [ "$testnum" = "30" ]; then
	# Coding Journal Content Review
	coding-journal-content-review $verbose
	error_count=$(($error_count + $?))

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}
