#!/bin/bash
# Author: Luke Hindman
# Date: Wed 27 Oct 2021 11:09:12 AM MDT
# Description:  Test bundle for CS121-Lab08

source test_functions.sh

###################################
#                                 #
#        Activity 1 Tests         #
#                                 #
###################################
function acceptance-test-activity1-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (TriangleCalculator)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="TriangleCalculator"
	local testprogram="TriangleCalculator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity1-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (TriangleCalculator.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="TriangleCalculator"
	local mainsrc="TriangleCalculator.java"
	local minlines=15
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity1-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (TriangleCalculator)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="TriangleCalculator"
	local testprogram="TriangleCalculator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity1-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Run TriangleCalculator)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="TriangleCalculator"
	local testprogram="java TriangleCalculator"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#        Activity 2 Tests         #
#                                 #
###################################
function acceptance-test-activity2-build() {
	local verbose=$1
	local testname="Acceptance Test - Build Activity (SphereCalculator)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="SphereCalculator"
	local testprogram="SphereCalculator.class"
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function acceptance-test-activity2-min-implementation() {
	local verbose=$1
	local testname="Acceptance Test - Minimum Implementation (SphereCalculator.java)"
	local testoutput="acceptance-test-activity1.out"
	local testdirectory="SphereCalculator"
	local mainsrc="SphereCalculator.java"
	local minlines=15
	local result
	local exit_status

	# Run acceptance test in subshell
	result=$( test-min-lines-check "$testname" "$testoutput" "$testdirectory" "$mainsrc" "$minlines" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function quality-test-activity2-build-check() {
	local verbose=$1
	local testname="Quality Test - Clean Build Check (SphereCalculator)"
	local testoutput="quality-test-activity1.out"
	local testdirectory="SphereCalculator"
	local testprogram="SphereCalculator.class"
	local result
	local exit_status

	# Run quality test in subshell
	result=$( test-clean-build-check "$testname" "$testoutput" "$testdirectory" "$testprogram" "$verbose" )

	exit_status=$?
	echo "$result"
	return $exit_status
}

function integration-test-activity2-manual-test() {
	local verbose=$1
	local testname="Integration Test - Manual Test (Run SphereCalculator)"
	local testoutput="integration-test-activity1.out"
	local testinput=""
	local expectedoutput=""
	local testdirectory="SphereCalculator"
	local testprogram="java SphereCalculator"
	local result
	local exit_status

	echo "${testname}"
	exit_status=0
	return $exit_status
}


###################################
#                                 #
#             Usage               #
#                                 #
###################################
function usage() {
	echo "Usage: test_bundle.sh -t <test_num> [-v]"
	echo -e "\nLabWarmup Test Options:"
	echo -e "-t 10\tAcceptance Tests"
	echo -e "-t 11\tQuality Tests"
	echo -e "-t 12\tUnit and Integration Tests"
	echo -e "\nLabActivity Test Options:"
	echo -e "-t 20\tAcceptance Tests"
	echo -e "-t 21\tQuality Tests"
	echo -e "-t 22\tUnit and Integration Tests"
}

###################################
#                                 #
#          Program Menu           #
#                                 #
###################################

testnum=""
verbose=0
error_count=0

while getopts t:v flag
do
    case "${flag}" in
        t) testnum=${OPTARG};;
		v) verbose=1;;
    esac
done

if [ "$testnum" = "" ];
then
	usage
	exit 1
fi

if [ "$testnum" = "1" ];
then
	echo "running test $testnum"
elif [ "$testnum" = "10" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity1-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity1-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "11" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "12" ];
then
	num_passed=0

	# LabActivity Code Quality Tests
	quality-test-activity1-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "20" ];
then
	num_passed=0
	# LabActivity Acceptance Tests
	acceptance-test-activity2-build $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	acceptance-test-activity2-min-implementation $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed + 1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	# echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "21" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=1
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`
elif [ "$testnum" = "22" ];
then
	num_passed=0
	# LabActivity Code Quality Tests
	quality-test-activity2-build-check $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	# LabActivity Code Completeness Tests
	integration-test-activity1-manual-test $verbose
	if [ $? == 0 ]; then num_passed=$(($num_passed+1)); fi

	num_tests=2
	score=`bc <<< "scale=3; 100.0 * $num_passed/$num_tests"`
	echo "Score: $score%"
	error_count=`expr $num_tests - $num_passed`

else
	echo "Unknown Test: $testnum"
	usage
	exit 1
fi

exit ${error_count}


